-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: localhost    Database: biomed_app
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addons`
--

DROP TABLE IF EXISTS `addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int NOT NULL DEFAULT '0',
  `badge_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addons`
--

LOCK TABLES `addons` WRITE;
/*!40000 ALTER TABLE `addons` DISABLE KEYS */;
INSERT INTO `addons` VALUES (1,'Pre-Conference Metagenomics Workshop','Intensive one-day hands-on training. Must be added to your registration.',500,'Limited Seats',1,'2026-10-05 01:01:11','2026-10-05 01:01:11');
/*!40000 ALTER TABLE `addons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `award_applications`
--

DROP TABLE IF EXISTS `award_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `award_applications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `award_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `award_applications`
--

LOCK TABLES `award_applications` WRITE;
/*!40000 ALTER TABLE `award_applications` DISABLE KEYS */;
INSERT INTO `award_applications` VALUES (3,'Faculty Award for excellence in\r\nOne Health research','award_applications/1790576120_Faculty_Award_for_excellence_in__One_Health_research.pdf','Kanchi_Vani_Vidyalaya_Annual_Report_2026_27_CLEAN_FINAL (1) (1).pdf','2026-09-28 00:45:20','2026-09-28 00:45:20'),(4,'Faculty Award for excellence in\r\nOne Health research','award_applications/1790661860_Faculty_Award_for_excellence_in__One_Health_research.pdf','State Recogn. Letter.pdf','2026-09-29 00:34:20','2026-09-29 00:34:20'),(5,'Faculty Award for excellence in\r\nOne Health research','award_applications/1790661901_Faculty_Award_for_excellence_in__One_Health_research.pdf','Building Licence.pdf','2026-09-29 00:35:01','2026-09-29 00:35:01');
/*!40000 ALTER TABLE `award_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `awards`
--

DROP TABLE IF EXISTS `awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `awards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `benefits` text COLLATE utf8mb4_unicode_ci,
  `eligibility` text COLLATE utf8mb4_unicode_ci,
  `guidelines` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `awards`
--

LOCK TABLES `awards` WRITE;
/*!40000 ALTER TABLE `awards` DISABLE KEYS */;
INSERT INTO `awards` VALUES (1,'Best Scholar Award','fa-solid fa-graduation-cap','#009688','Honoring outstanding academic performance, research contribution, and scholastic excellence. Cash Prize: ₹10,000','Cash Prize of ₹10,000.\nCertificate of Distinction & Memento.\nPublic recognition during the valedictory ceremony.\nFeatured spotlight in conference proceedings.','Open to students, research scholars, and early-career academicians.\nMust present an accepted paper or poster at the conference.','Evaluated based on academic merit, research quality, and presentation delivery.',1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(2,'Best Researcher Award','fa-solid fa-award','#0284c7','Recognizing groundbreaking research, high-impact scientific work, and domain leadership. Cash Prize: ₹25,000','Cash Prize of ₹25,000.\nCertificate of Research Excellence & Trophy.\nOpportunity to deliver a special guest presentation.\nFeatured showcase on the official portal and media release.','Open to senior researchers, faculty members, and scientists with significant research contributions.\nRequires submission of research abstract and portfolio.','Evaluated by the Advisory Committee based on research novelty, domain impact, and presentation.',2,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(3,'Entrepreneur Award','fa-solid fa-rocket','#d97706','Celebrating innovative biomedical models, patent innovations, and startup leadership. Cash Prize: ₹25,000','Cash Prize of ₹25,000.\nCertificate of Innovation & Entrepreneur Trophy.\nMentorship & incubation networking with industry investors.\nDirect feature in the startup showcase.','Open to student entrepreneurs, startup founders, and innovators presenting scalable solutions or patents.','Pitch deck or prototype demonstration required during the Innovation & Pitch session.',3,'2026-10-05 01:01:11','2026-10-05 01:01:11');
/*!40000 ALTER TABLE `awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `committee_members`
--

DROP TABLE IF EXISTS `committee_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `committee_members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `committee_members`
--

LOCK TABLES `committee_members` WRITE;
/*!40000 ALTER TABLE `committee_members` DISABLE KEYS */;
INSERT INTO `committee_members` VALUES (1,'Dr. P. Wilson','Principal & Secretary, MCC','leadership','chief_patron',NULL,1,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(2,'Dr. J. Jannet Vennila','Vice Principal (SFS), MCC','leadership','patrons',NULL,2,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(3,'Dr. V. Mahalakshmi','Associate Professor & Head,\nDepartment of Microbiology','leadership','convenor',NULL,1,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(4,'Dr. S. Sahila','Head, Department of Chemistry (SFS)','leadership','convenor',NULL,4,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(5,'Dr. Belinda','Director, Extension Programmes','leadership','co_convenors',NULL,5,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(6,'Dr. M. Beutline Malgija','Bioinformatician, MMIP','leadership','co_convenors',NULL,6,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(7,'Dr. Atul Kumar','Assistant Researcher, Faculty of Medicine, Biomedical Center, Lund University, Sweden','advisory_committee','international',NULL,7,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(8,'Dr. R. Aldrin Denny','Founder and CEO, Medizen Incorporation, Boston, USA','advisory_committee','international',NULL,8,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(9,'Dr. Shobana Sekhar','Computational Biologist, USA','advisory_committee','international',NULL,9,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(10,'Dr. Md. Khalilur Rahman','Professor, Department of Biochemistry & Molecular Biology, University of Dhaka, Bangladesh','advisory_committee','international',NULL,10,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(11,'Dr. S. Parthsarathy','Former Professor & Head, Department of Bioinformatics, Bharathidasan University, Trichirapalli','advisory_committee','national',NULL,11,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(12,'Dr. P. P. Mathur','Professor & Head, Department of Biochemistry & Molecular Biology and Dean, School of Life Sciences, Pondicherry University; Former Vice-Chancellor, KIIT University','advisory_committee','national',NULL,12,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(13,'Dr. Narasimhan D','Member, Expert Committee on Access and Benefit Sharing, National Biodiversity Authority; National Evaluation Committee of PBRs','advisory_committee','national',NULL,13,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(14,'Dr. T. N. Ravishankar','IMA Former President, TNSB','advisory_committee','national',NULL,14,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(15,'Dr. Kamalakannan Kailasam','Professor, Scientist-G, Institute of Nano Science and Technology (INST), Mohali','advisory_committee','national',NULL,15,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(16,'Prof. Dr. G. Senthilvel','Director, National Institute of Siddha (NIS), Chennai','advisory_committee','national',NULL,16,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(17,'Dr. Meenakshi Sundaram Malayappan','M.D (S), Ph.D, Professor at National Institute of Siddha, Chennai','advisory_committee','national',NULL,17,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(18,'Dr. Vijayakumar Varadarajan','Former Professor of Neonatology, MMC','advisory_committee','national',NULL,18,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(19,'Dr. M. Kathiresan','P.C. Ray Department of Chemistry, National Institute of Technology Puducherry','advisory_committee','national',NULL,19,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(20,'Dr. Wilson Aruni','Vice Chancellor, Amity University, Mumbai','advisory_committee','national',NULL,20,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(21,'Prof. K.R.S Sambasiva Rao','Vice Chancellor at Dr. RVR NRI Institute of Technology Deemed to be University, Vijayawada, Andhra Pradesh, India','advisory_committee','national',NULL,21,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(22,'Dr. K. Kavitha','Associate Professor, Dept of Microbiology','leadership','organizing_secretaries',NULL,2,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(23,'Dr. Bebin. A','Assistant Professor, Department of Chemistry (SFS)','leadership','organizing_secretaries',NULL,23,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(24,'Dr. S. Niren Andrew','Assistant Professor, Department of Microbiology','organizing_committee',NULL,NULL,24,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(25,'Dr. S. Premina','Assistant Professor','organizing_committee',NULL,NULL,1,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(26,'Dr. S. Abirami','Assistant Professor','organizing_committee',NULL,NULL,2,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(27,'Dr. P. Hanumantha Rao','Associate Professor','organizing_committee',NULL,NULL,3,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(28,'Dr. T. Sathish Kumar','Associate Professor','organizing_committee',NULL,NULL,4,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(29,'Dr. V. Vedha','Assistant Professor','organizing_committee',NULL,NULL,5,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(30,'Dr. K. Balakumar','Assistant Professor','organizing_committee',NULL,NULL,6,1,'2026-09-15 06:57:36','2026-10-05 01:01:11'),(31,'Dr. Neginah Vijayasingh J','Assistant Professor, Department of Microbiology','organizing_committee',NULL,NULL,31,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(32,'Dr. Daniel Abraham','Assistant Professor, Department of Chemistry (SFS)','organizing_committee',NULL,NULL,32,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(33,'Dr. K. Vijayalakshmi','Assistant Professor, Department of Chemistry (SFS)','organizing_committee',NULL,NULL,33,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(34,'Dr. T. Premalatha','Medical Officer, Madras Christian College','organizing_committee',NULL,NULL,34,1,'2026-09-15 06:57:36','2026-09-15 06:57:36'),(35,'Mr. R. Sridhar','Vice Principal (Administration), MCC','leadership','patrons',NULL,1,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(36,'Dr. S. Niren Andrew','Assistant Professor, Dept of Microbiology','leadership','organizing_secretaries',NULL,1,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(37,'Dr. Neginah Vijayasingh','Assistant Professor','organizing_committee',NULL,NULL,7,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(38,'Dr. S. Vincent','Member Secretary, Tamil Nadu State Council for Science and Technology.','advisory_committee',NULL,'fa-solid fa-user-shield',1,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(39,'Dr. D. Alex Anand','Associate Professor, Department of Bioinformatics & The Centre for Molecular Data Science','advisory_committee',NULL,'fa-solid fa-user-shield',2,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(40,'Dr. Joyce Sudandara Priya','Head, Department of Botany, MCC.','advisory_committee',NULL,'fa-solid fa-user-shield',3,1,'2026-10-05 01:01:11','2026-10-05 01:01:11');
/*!40000 ALTER TABLE `committee_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deadlines`
--

DROP TABLE IF EXISTS `deadlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deadlines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deadline_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `phase` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'PHASE 01',
  `date_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'fa-solid fa-file-arrow-up',
  `tag_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Call for Abstracts',
  `tag_icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'fa-solid fa-circle-dot',
  `color_theme` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'teal',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deadlines`
--

LOCK TABLES `deadlines` WRITE;
/*!40000 ALTER TABLE `deadlines` DISABLE KEYS */;
INSERT INTO `deadlines` VALUES (1,'Submission of Abstract','2026-10-07',1,1,'2026-10-06 00:01:20','2026-10-06 00:01:20','PHASE 01','Oct 07, 2026','Online submission portal open for structured scientific abstracts across all conference tracks.','fa-solid fa-file-arrow-up','Call for Abstracts','fa-solid fa-circle-dot','teal'),(2,'Acceptance of Abstract','2026-10-15',1,2,'2026-10-06 00:01:20','2026-10-06 00:01:20','PHASE 02','Oct 15, 2026','Formal notification sent to authors regarding peer review outcome and presentation mode.','fa-solid fa-envelope-open-text','Review & Intimation','fa-regular fa-clock','navy'),(3,'Full Paper Submission','2026-11-15',1,3,'2026-10-06 00:01:21','2026-10-06 00:01:21','PHASE 03','Nov 15, 2026','Camera-ready manuscript submission for publication in indexed conference proceedings.','fa-solid fa-book-journal-whills','Final Proceedings','fa-solid fa-award','lime');
/*!40000 ALTER TABLE `deadlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hero_organizers`
--

DROP TABLE IF EXISTS `hero_organizers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hero_organizers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hero_organizers`
--

LOCK TABLES `hero_organizers` WRITE;
/*!40000 ALTER TABLE `hero_organizers` DISABLE KEYS */;
INSERT INTO `hero_organizers` VALUES (5,'DEPARTMENT OF MICROBIOLOGY, MCC',0,1,'2026-09-15 06:03:39','2026-09-15 06:08:56'),(6,'DEPARTMENT OF CHEMISTRY, MCC',1,1,'2026-09-15 06:03:39','2026-09-15 06:08:56');
/*!40000 ALTER TABLE `hero_organizers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `highlights`
--

DROP TABLE IF EXISTS `highlights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `highlights` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_number` int NOT NULL,
  `sort_order` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `highlights`
--

LOCK TABLES `highlights` WRITE;
/*!40000 ALTER TABLE `highlights` DISABLE KEYS */;
INSERT INTO `highlights` VALUES (1,'Plenary Sessions',1,0,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(2,'Invited Talks',1,1,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(3,'Oral & Poster presentations',1,2,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(4,'Six thematic tracks in One Health-  Separate tracks for Medical Practitioners & Industry',1,3,'2026-09-25 06:47:54','2026-10-06 06:33:22'),(5,'Hackathon',2,4,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(6,'Innovator Pitch',2,5,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(7,'Industry Connect',2,6,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(8,'Pre-Conference Consultation',2,7,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(9,'Conference proceedings as Publications in Scopus / WoS Journals',3,8,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(10,'Panel Discussions',3,9,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(11,'Policy Roundtable Discussions',3,10,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(12,'Distinguished Awards and Prizes',3,11,'2026-09-25 06:47:54','2026-09-25 06:47:54'),(13,'Industry Expo',1,5,'2026-10-06 06:30:39','2026-10-06 06:34:37'),(14,'Research/ Innovation Showcase',3,6,'2026-10-06 06:31:23','2026-10-06 06:31:23'),(15,'Networking Section',2,7,'2026-10-06 06:31:50','2026-10-06 06:35:02');
/*!40000 ALTER TABLE `highlights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interest_options`
--

DROP TABLE IF EXISTS `interest_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interest_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interest_options`
--

LOCK TABLES `interest_options` WRITE;
/*!40000 ALTER TABLE `interest_options` DISABLE KEYS */;
INSERT INTO `interest_options` VALUES (1,'Plenary',0,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(2,'Keynote',1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(3,'Invited',2,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(4,'Oral',3,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(5,'Poster Presentation',4,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(6,'Delegate',5,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(7,'Submit Abstract',10,'2026-08-19 23:29:16','2026-08-19 23:29:16'),(8,'Plenary',0,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(9,'Keynote',1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(10,'Invited',2,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(11,'Oral',3,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(12,'Poster Presentation',4,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(13,'Delegate',5,'2026-10-05 01:01:11','2026-10-05 01:01:11');
/*!40000 ALTER TABLE `interest_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` int DEFAULT NULL,
  `alt_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_06_03_064455_create_paper_submissions_table',1),(5,'2026_06_03_064455_create_registrations_table',1),(6,'2026_06_03_071653_add_is_admin_to_users_table',1),(7,'2026_06_03_072427_create_media_table',1),(8,'2026_06_03_085730_create_registration_fees_table',1),(9,'2026_06_03_092031_create_site_settings_table',1),(10,'2026_06_03_092058_create_deadlines_table',1),(11,'2026_06_03_101032_create_addons_table',1),(12,'2026_06_03_101032_create_policies_table',1),(13,'2026_06_04_063416_add_description_to_addons_table',1),(14,'2026_06_04_093434_create_interest_options_table',1),(15,'2026_06_09_071849_create_registration_fields_table',1),(16,'2026_06_09_071941_add_form_data_to_registrations_table',1),(17,'2026_06_09_085615_create_speakers_table',1),(18,'2026_06_09_091912_add_type_to_speakers_table',1),(19,'2026_06_09_093715_make_title_nullable_on_speakers_table',1),(20,'2026_06_09_100750_create_topics_table',1),(21,'2026_06_10_095801_add_category_name_to_registrations_table',1),(22,'2026_06_10_100218_make_registrations_columns_nullable',1),(23,'2026_06_12_081920_create_highlights_table',1),(24,'2026_06_12_110510_create_submit_paper_fields_table',1),(25,'2026_06_12_110549_update_paper_submissions_table',1),(26,'2026_06_15_050008_create_committee_members_table',1),(27,'2026_06_15_052757_create_sponsor_packages_table',1),(28,'2026_06_15_053935_create_awards_table',1),(29,'2026_08_18_092712_add_details_to_speakers_table',1),(30,'2026_08_18_164858_add_price_online_to_registration_fees_table',1),(31,'2026_09_07_091441_create_hero_organizers_table',2),(32,'2026_09_08_000000_create_tracks_table',3),(33,'2026_09_28_000001_add_missing_columns_to_registrations_table',4),(34,'2026_09_28_000002_add_presentation_columns_to_registrations_table',5),(35,'2026_09_28_000003_create_award_applications_table',6),(36,'2026_10_05_000001_create_partner_logos_table',7),(37,'2026_10_06_000001_add_fields_to_deadlines_table',8),(38,'2026_10_07_000001_add_description_and_badge_to_tracks_table',9),(39,'2026_10_08_000001_make_image_path_nullable_on_speakers_table',10);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paper_submissions`
--

DROP TABLE IF EXISTS `paper_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paper_submissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paper_submissions`
--

LOCK TABLES `paper_submissions` WRITE;
/*!40000 ALTER TABLE `paper_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `paper_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partner_logos`
--

DROP TABLE IF EXISTS `partner_logos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partner_logos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner_logos`
--

LOCK TABLES `partner_logos` WRITE;
/*!40000 ALTER TABLE `partner_logos` DISABLE KEYS */;
INSERT INTO `partner_logos` VALUES (1,'Madras Christian College (MCC)','images/MMC-LOGO-2.jpg','https://mcc.edu.in',3,1,'2026-10-06 06:50:29','2026-10-07 04:48:33'),(4,'Microbiologists Society, India','images/microbiologists_society.png','https://microbiosoc.org',6,1,'2026-10-06 06:50:29','2026-10-07 04:48:33'),(9,'National Institute of Siddha (NIS)','images/nis-logo-transparent.png','https://nischennai.org',5,1,'2026-10-07 04:48:33','2026-10-07 04:48:33'),(10,'---','images/1791374861_ChatGPT_Image_Oct_5__2026__05_34_56_PM.png','--',7,1,'2026-10-07 06:37:41','2026-10-07 06:37:41'),(11,'77','images/1791374966_ChatGPT_Image_Sep_18__2026__03_21_11_PM.png','88',8,1,'2026-10-07 06:39:26','2026-10-07 06:39:26');
/*!40000 ALTER TABLE `partner_logos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `policies`
--

DROP TABLE IF EXISTS `policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `policies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `policies`
--

LOCK TABLES `policies` WRITE;
/*!40000 ALTER TABLE `policies` DISABLE KEYS */;
INSERT INTO `policies` VALUES (1,'WHAT\'S INCLUDED IN YOUR PAYMENT','<div style=\"display: flex; flex-wrap: wrap; gap: 30px;\">\n                            <div style=\"flex: 1; min-width: 300px;\">\n                                <h4 style=\"margin-top: 0; margin-bottom: 15px; font-weight: 400; color: #555;\">Registration Fee</h4>\n                                <ul style=\"list-style-type: none; padding-left: 0; margin: 0;\">\n                                    <li style=\"margin-bottom: 8px;\"><i class=\"fa-solid fa-check\" style=\"margin-right: 8px; color: #000;\"></i> Full program at the whole conference</li>\n                                    <li style=\"margin-bottom: 8px;\"><i class=\"fa-solid fa-check\" style=\"margin-right: 8px; color: #000;\"></i> Lunch on during the conference</li>\n                                    <li style=\"margin-bottom: 8px;\"><i class=\"fa-solid fa-check\" style=\"margin-right: 8px; color: #000;\"></i> Coffee Break</li>\n                                    <li style=\"margin-bottom: 8px;\"><i class=\"fa-solid fa-check\" style=\"margin-right: 8px; color: #000;\"></i> Welcome Coffee</li>\n                                </ul>\n                            </div>\n                        </div>',1,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(2,'REGISTRATION CANCELLATION POLICY','<ul style=\"padding-left: 20px; margin-top: 0; margin-bottom: 0; color: #475569; line-height: 1.7;\">\n                            <li style=\"margin-bottom: 10px;\">Cancellations made &ge;120 days prior to the event start date will receive a full refund, less a $150 administrative fee for processing and banking charges.</li>\n                            <li style=\"margin-bottom: 10px;\">Cancellations made between 119 to 90 days prior to the event start date are eligible for a 50% refund of the registration fee.</li>\n                            <li style=\"margin-bottom: 10px;\">Cancellations requested within 89 days or fewer from the event start date are non-refundable, including registration and accommodation-related charges.</li>\n                        </ul>',2,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(3,'WHAT\'S INCLUDED IN YOUR PAYMENT','<div style=\"display: flex; flex-wrap: wrap; gap: 30px;\">\n                            <div style=\"flex: 1; min-width: 300px;\">\n                                <h4 style=\"margin-top: 0; margin-bottom: 15px; font-weight: 400; color: #555;\">Registration Fee</h4>\n                                <ul style=\"list-style-type: none; padding-left: 0; margin: 0;\">\n                                    <li style=\"margin-bottom: 8px;\"><i class=\"fa-solid fa-check\" style=\"margin-right: 8px; color: #000;\"></i> Full program at the whole conference</li>\n                                    <li style=\"margin-bottom: 8px;\"><i class=\"fa-solid fa-check\" style=\"margin-right: 8px; color: #000;\"></i> Lunch on during the conference</li>\n                                    <li style=\"margin-bottom: 8px;\"><i class=\"fa-solid fa-check\" style=\"margin-right: 8px; color: #000;\"></i> Coffee Break</li>\n                                    <li style=\"margin-bottom: 8px;\"><i class=\"fa-solid fa-check\" style=\"margin-right: 8px; color: #000;\"></i> Welcome Coffee</li>\n                                </ul>\n                            </div>\n                        </div>',1,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(4,'REGISTRATION CANCELLATION POLICY','<ul style=\"padding-left: 20px; margin-top: 0; margin-bottom: 0; color: #475569; line-height: 1.7;\">\n                            <li style=\"margin-bottom: 10px;\">Cancellations made &ge;120 days prior to the event start date will receive a full refund, less a $150 administrative fee for processing and banking charges.</li>\n                            <li style=\"margin-bottom: 10px;\">Cancellations made between 119 to 90 days prior to the event start date are eligible for a 50% refund of the registration fee.</li>\n                            <li style=\"margin-bottom: 10px;\">Cancellations requested within 89 days or fewer from the event start date are non-refundable, including registration and accommodation-related charges.</li>\n                        </ul>',2,1,'2026-10-05 01:01:11','2026-10-05 01:01:11');
/*!40000 ALTER TABLE `policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration_fees`
--

DROP TABLE IF EXISTS `registration_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registration_fees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_inr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_online` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_usd` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `features` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `is_highlighted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `price_usd_online` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration_fees`
--

LOCK TABLES `registration_fees` WRITE;
/*!40000 ALTER TABLE `registration_fees` DISABLE KEYS */;
INSERT INTO `registration_fees` VALUES (1,'Student','1000','1500',NULL,'[\"Registration includes conference kit, certificate, lunch and refreshment.\"]',1,1,0,'2026-10-05 01:01:11','2026-10-05 01:01:11',NULL,NULL),(2,'Research Scholar','1500','2000',NULL,'[\"Registration includes conference kit, certificate, lunch and refreshment.\"]',1,2,0,'2026-10-05 01:01:11','2026-10-05 01:01:11',NULL,NULL),(3,'Faculty/Scientist','2000','3000',NULL,'[\"Registration includes conference kit, certificate, lunch and refreshment.\"]',1,3,1,'2026-10-05 01:01:11','2026-10-05 01:01:11',NULL,NULL),(4,'Industrialists','5000','5000',NULL,'[\"Registration includes conference kit, certificate, lunch and refreshment.\"]',1,4,0,'2026-10-05 01:01:11','2026-10-05 01:01:11',NULL,NULL);
/*!40000 ALTER TABLE `registration_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration_fields`
--

DROP TABLE IF EXISTS `registration_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registration_fields` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `placeholder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  `options` json DEFAULT NULL,
  `grid_column` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'span 12',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration_fields`
--

LOCK TABLES `registration_fields` WRITE;
/*!40000 ALTER TABLE `registration_fields` DISABLE KEYS */;
INSERT INTO `registration_fields` VALUES (1,'title','Title','select','Select Title',1,'[\"Dr.\", \"Prof.\", \"Mr.\", \"Ms.\", \"Mrs.\"]','span 2',1,'2026-10-05 06:05:05','2026-10-05 06:05:05'),(2,'name','Full Name','text','Enter your full name',1,NULL,'span 10',2,'2026-10-05 06:05:05','2026-10-05 06:05:05'),(3,'email','Email Address','email','Enter your email',1,NULL,'span 4',3,'2026-10-05 06:05:05','2026-10-05 06:05:05'),(4,'phone','Phone Number','text','Enter your phone number',1,NULL,'span 4',4,'2026-10-05 06:05:05','2026-10-05 06:05:05'),(5,'gender','Gender','select','Select Gender',1,'[\"Male\", \"Female\", \"Other\", \"Prefer not to say\"]','span 4',5,'2026-10-05 06:05:05','2026-10-05 06:05:05'),(6,'organization','Organization/Institution','text','Organization/Institution',1,NULL,'span 12',6,'2026-10-05 06:05:05','2026-10-05 06:05:05'),(8,'city','City','text','Enter your city name',0,NULL,'span 4',8,'2026-10-05 06:05:05','2026-10-05 06:05:05'),(9,'country','Country','text','Enter your Country',0,NULL,'span 4',9,'2026-10-05 06:05:05','2026-10-05 06:05:05'),(10,'postal_code','Postal Code','text','Enter your Postal Code',0,NULL,'span 4',10,'2026-10-05 06:05:05','2026-10-05 06:05:05');
/*!40000 ALTER TABLE `registration_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrations`
--

DROP TABLE IF EXISTS `registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `form_data` json DEFAULT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `addons` json DEFAULT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interested_in` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reg_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abstract_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrations`
--

LOCK TABLES `registrations` WRITE;
/*!40000 ALTER TABLE `registrations` DISABLE KEYS */;
INSERT INTO `registrations` VALUES (4,'2026-09-27 23:55:31','2026-09-28 00:40:14','{\"city\": \"chennai\", \"name\": \"zubairya salam khan\", \"email\": \"zubairyakhan48@gmail.com\", \"phone\": \"09043898231\", \"title\": \"Dr.\", \"country\": \"India\", \"postal_code\": \"600117\", \"organization\": \"mkjv\", \"abstract_file\": \"abstracts/KgnJsjiDI9PMeCfFiBuB4rtT2xnZYY96U25nLZCk.docx\", \"interested_in\": \"Delegate\", \"transaction_id\": \"22345678\", \"registration_type\": \"Presentation\"}','completed',750.00,'[]','Registration','Dr.','zubairya salam khan','zubairyakhan48@gmail.com','09043898231','mkjv','chennai','India','600117','Delegate',NULL,'Txn: 22345678','Presentation','abstracts/KgnJsjiDI9PMeCfFiBuB4rtT2xnZYY96U25nLZCk.docx'),(8,'2026-09-28 00:37:17','2026-09-28 00:40:14','{\"city\": \"chennai\", \"name\": \"Karishmaa M\", \"email\": \"Karishmaam9raj@gmail.com\", \"phone\": \"125987654321\", \"title\": \"Ms.\", \"country\": \"India\", \"postal_code\": \"600117\", \"organization\": \"Sathyabama\", \"interested_in\": \"Poster Presentation\", \"transaction_id\": \"123456789\", \"registration_type\": \"Participation\"}','completed',750.00,'[]','Registration','Ms.','Karishmaa M','Karishmaam9raj@gmail.com','125987654321','Sathyabama','chennai','India','600117','Poster Presentation',NULL,'Txn: 123456789','Participation',NULL),(9,'2026-09-28 00:42:17','2026-09-28 00:42:17','{\"city\": \"chennai\", \"name\": \"opiiuy\", \"email\": \"zubairyakhan48@gmail.com\", \"phone\": \"1234567890\", \"title\": \"Ms.\", \"country\": \"India\", \"postal_code\": \"600000\", \"organization\": \"sit\", \"interested_in\": \"Poster Presentation\", \"transaction_id\": \"1234567\", \"registration_type\": \"Participation\"}','completed',750.00,'[]','Registration','Ms.','opiiuy','zubairyakhan48@gmail.com','1234567890','sit','chennai','India','600000','Poster Presentation','750','Txn: 1234567','Participation',NULL),(10,'2026-09-28 00:43:47','2026-09-28 00:43:47','{\"city\": \"chennai\", \"name\": \"priya\", \"email\": \"zubairyakhan48@gmail.com\", \"phone\": \"123456780\", \"title\": \"Ms.\", \"country\": \"India\", \"postal_code\": \"600117\", \"organization\": \"sit\", \"abstract_file\": \"abstracts/1790576027_Kanchi_Vani_Vidyalaya_Annual_Report_2026_27_CLEAN_FINAL__1_.pdf\", \"interested_in\": \"Oral\", \"transaction_id\": \"1234567\", \"registration_type\": \"Presentation\", \"abstract_original_name\": \"Kanchi_Vani_Vidyalaya_Annual_Report_2026_27_CLEAN_FINAL (1).pdf\"}','completed',750.00,'[]','Registration','Ms.','priya','zubairyakhan48@gmail.com','123456780','sit','chennai','India','600117','Oral','750','Txn: 1234567','Presentation','abstracts/1790576027_Kanchi_Vani_Vidyalaya_Annual_Report_2026_27_CLEAN_FINAL__1_.pdf'),(11,'2026-09-29 00:38:26','2026-09-29 00:38:26','{\"city\": \"chennai\", \"name\": \"szdxfghjkl;\", \"email\": \"zubairyasalamkhan213@gmail.com\", \"phone\": \"123456789\", \"title\": \"Ms.\", \"country\": \"India\", \"postal_code\": \"12345678\", \"organization\": \"sit\", \"abstract_file\": \"abstracts/1790662106_Building_Licence.pdf\", \"interested_in\": \"Delegate\", \"transaction_id\": \"123456789\", \"registration_type\": \"Presentation\", \"abstract_original_name\": \"Building Licence.pdf\"}','completed',2000.00,'[]','Registration','Ms.','szdxfghjkl;','zubairyasalamkhan213@gmail.com','123456789','sit','chennai','India','12345678','Delegate','2000','Txn: 123456789','Presentation','abstracts/1790662106_Building_Licence.pdf'),(12,'2026-10-07 01:55:27','2026-10-07 01:55:27','{\"city\": \"cvbnm,.\", \"name\": \"asdfghjk\", \"email\": \"zubairyakhan48@gmail.com\", \"phone\": \"cvbnm,\", \"title\": \"Ms.\", \"gender\": \"Female\", \"country\": \"vbnm,\", \"postal_code\": \".34567890\", \"id_card_file\": \"id_cards/1791357927_id_Industry_sponsor_Brochure-1.pdf\", \"organization\": \"wertyuiop\", \"abstract_file\": \"abstracts/1791357927_Hospital_sponsor_Brochure.pdf\", \"transaction_id\": \"345678\", \"registration_type\": \"Presentation\", \"presentation_track\": \"Track III: Integrating Environment and Climate Change in One Health\", \"id_card_original_name\": \"Industry sponsor Brochure-1.pdf\", \"abstract_original_name\": \"Hospital sponsor Brochure.pdf\", \"presentation_event_type\": \"Oral Presentation\"}','completed',1000.00,'[]','Registration','Ms.','asdfghjk','zubairyakhan48@gmail.com','cvbnm,','wertyuiop','cvbnm,.','vbnm,','.34567890',NULL,'1000','Txn: 345678','Presentation','abstracts/1791357927_Hospital_sponsor_Brochure.pdf');
/*!40000 ALTER TABLE `registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('yuKdGXhlac3VorsEi5oQpCwVAfkuIpL2lPdJMBSe',2,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0','eyJfdG9rZW4iOiJaNVlWY2p3Q3dFQWFVSkY3TmQ2Z2RYYTE4cHpxVTRHbXBsS0hnRGxHIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwidXJsIjpbXSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1791439364);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=566 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'contact_email','gohc2026@gmail.com','text','contact','Contact Email','2026-08-19 04:16:38','2026-08-19 04:16:38'),(2,'contact_phone','+91 9789582404','text','contact','Contact Phone 1','2026-08-19 04:16:38','2026-10-07 01:50:26'),(3,'contact_address','Madras Christian College, Tambaram, Chennai','text','contact','Address','2026-08-19 04:16:38','2026-08-19 04:16:38'),(4,'topbar_format','Online | In-person','text','contact','Event Format (Topbar)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(5,'hero_title','GLOBAL ONE HEALTH CONFLUENCE  2026','textarea','hero','Main Heading','2026-08-19 04:16:38','2026-10-05 01:01:11'),(6,'hero_subtitle','Bridging Microbes, Molecules & Mankind for Sustainability','text','hero','Subtitle','2026-08-19 04:16:38','2026-08-19 04:16:38'),(7,'hero_organized_by','Jointly organized by Department of Microbiology & Department of Chemistry (SFS), Madras Christian College','text','hero','Organized By','2026-08-19 04:16:38','2026-10-05 01:01:11'),(8,'hero_dates','21st and 22nd December 2026','text','hero','Event Dates','2026-08-19 04:16:38','2026-10-05 01:01:11'),(9,'hero_location','Madras Christian College, Chennai','text','hero','Event Location','2026-08-19 04:16:38','2026-08-19 04:16:38'),(10,'about_conference','The Global One Health Confluence 2026 is envisioned as a flagship international interdisciplinary forum that brings together leading scientists, academicians, clinicians, policymakers, industry leaders, innovators, entrepreneurs, and students to address emerging global health challenges through the One Health framework.\n\nRecognizing the intricate interdependence between human health, animal health, environmental sustainability, and technological innovation, the conference seeks to foster scientific dialogue, collaborative research, translational innovation, and policy engagement. The event aligns with the United Nations Sustainable Development Goals (SDGs) and India\'s vision of promoting sustainable, inclusive, and evidence-based solutions for future health security.\n\nOrganized by the Departments of Microbiology and Chemistry (SFS), Madras Christian College, in collaboration with reputed national and international institutions, professional societies, research organizations, healthcare institutions, and industry partners, this confluence will serve as a premier platform for knowledge exchange, interdisciplinary networking, innovation showcasing, and strategic collaborations.','textarea','about','About Conference','2026-08-19 04:16:38','2026-08-19 04:16:38'),(11,'about_mission','To connect researchers, thought leaders, and institutions through impactful events that inspire knowledge-sharing and real-world solutions.','textarea','about','Our Mission','2026-08-19 04:16:38','2026-08-19 04:16:38'),(12,'about_vision','To build a global platform that showcases research, fosters collaboration, and drives innovation across disciplines.','textarea','about','Our Vision','2026-08-19 04:16:38','2026-08-19 04:16:38'),(13,'about_mcc','Madras Christian College (MCC) is one of India’s premier educational institutions, founded by Scottish missionaries in 1837. Over the years, it has evolved into an institution committed to academic excellence, spiritual vitality, and social relevance.\n\nIn 2018, MCC was re-accredited by NAAC with an \'A\' Grade and ranks 14th in the NIRF rankings, reflecting its high academic standards, robust research output, and unwavering dedication to quality education.\n\nMCC established the MCC Boyd-Tandon School of Business in 2016 with the vision of providing world-class business education. The Centre for Computational Informatics serves as a research hub dedicated to advancing computational science through cutting-edge research, impactful collaborations, and hands-on training.\n\nTo further strengthen innovation and entrepreneurship, MCC launched the Institution’s Innovation Council in 2020 and the MCC-MRF Innovation Park (MMIP) in 2021. These initiatives foster advanced research, support innovation-driven startups, and nurture the next generation of entrepreneurs.','textarea','about','About Madras Christian College','2026-08-19 04:16:38','2026-08-19 22:54:34'),(14,'about_dept','The Department of Microbiology at Madras Christian College (MCC) was established in 2002 and has earned recognition for its academic excellence, leadership development, and commitment to research and social relevance.\n\nThe department offers a dynamic curriculum designed to equip students with the knowledge and skills required to explore emerging opportunities in the field of Microbiology, preparing them for both research and industry careers.\n\nSince 2018, the department has been a full-fledged research unit offering Ph.D. programmes in Microbiology and Applied Microbiology. Research activities span diverse disciplines within Microbiology, including areas aligned with the conference themes and emerging scientific developments.\n\nThe department is widely recognized for its strong industry-academia collaborations, faculty and student-driven innovations, active research contributions, and a culture that encourages intellectual property creation and patent development.','textarea','about','About Department of Microbiology','2026-08-19 04:16:38','2026-10-05 01:01:11'),(15,'mcc_stat1_title','1837','text','about','MCC Stat 1 (Title)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(16,'mcc_stat1_sub','Founded In','text','about','MCC Stat 1 (Subtitle)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(17,'mcc_stat2_title','\'A\' Grade','text','about','MCC Stat 2 (Title)','2026-08-19 04:16:38','2026-08-19 22:54:34'),(18,'mcc_stat2_sub','NAAC Accredited','text','about','MCC Stat 2 (Subtitle)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(19,'mcc_stat3_title','Rank 14','text','about','MCC Stat 3 (Title)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(20,'mcc_stat3_sub','NIRF Rankings','text','about','MCC Stat 3 (Subtitle)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(21,'about_simats','Saveetha Institute of Medical and Technical Sciences (SIMATS) is a prestigious Deemed-to-be-University located in Chennai, Tamil Nadu. Established in 2005, SIMATS has rapidly grown into a premier multidisciplinary institution offering high-quality education and research across Medicine, Dentistry, Engineering, Law, and Allied Health Sciences.\n\nSIMATS is accredited by NAAC with the highest \'A++\' Grade, signifying its world-class teaching standards, state-of-the-art infrastructure, and strong emphasis on research and development. The university ranks 11th in the \'University\' category under the National Institutional Ranking Framework (NIRF) in 2024.\n\nWith a focus on innovation and clinical excellence, SIMATS hosts advanced simulation labs, comprehensive research centers, and maintains active collaborations with top international institutions and industry leaders globally.','textarea','about','About SIMATS','2026-08-19 04:16:38','2026-08-19 04:16:38'),(22,'simats_stat1_title','2005','text','about','SIMATS Stat 1 (Title)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(23,'simats_stat1_sub','Established','text','about','SIMATS Stat 1 (Subtitle)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(24,'simats_stat2_title','\'A++\' Grade','text','about','SIMATS Stat 2 (Title)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(25,'simats_stat2_sub','NAAC Accredited','text','about','SIMATS Stat 2 (Subtitle)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(26,'simats_stat3_title','Rank 11','text','about','SIMATS Stat 3 (Title)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(27,'simats_stat3_sub','NIRF University','text','about','SIMATS Stat 3 (Subtitle)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(28,'about_chemistry','The Department of Chemistry (Self-Financed Stream - SFS) at Madras Christian College (MCC) was established in 2003 to provide comprehensive and industry-relevant chemical education. The department offers a highly sought-after M.Sc. in Chemistry program designed to bridge theoretical concepts with experimental application.\n\nThe curriculum is structured around modern developments in chemical sciences, covering advanced organic, inorganic, physical, analytical, and environmental chemistry. With well-equipped dedicated laboratories and independent research infrastructure, students are exposed to hands-on training and advanced analytical instrumentation.\n\nTo prepare students for professional success, the department fosters collaborations with national research laboratories and leading pharmaceutical and chemical industries, enabling students to undertake high-impact academic projects and internship opportunities.','textarea','about','About Department of Chemistry (SFS)','2026-08-19 04:16:38','2026-10-05 01:01:11'),(29,'participants_desc','Join the confluence to bridge microbes, molecules & mankind for a sustainable future.','textarea','participants','Section Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(30,'participant_1','Students &\nResearch Scholars','textarea','participants','Participant Type 1','2026-08-19 04:16:38','2026-08-19 04:16:38'),(31,'participant_2','Academicians &\nPolicy Makers','textarea','participants','Participant Type 2','2026-08-19 04:16:38','2026-08-19 04:16:38'),(32,'participant_3','Research\nScientists','textarea','participants','Participant Type 3','2026-08-19 04:16:38','2026-08-19 04:16:38'),(33,'participant_4','Health\nProfessionals','text','participants','Participant Type 4','2026-08-19 04:16:38','2026-08-19 04:16:38'),(34,'participant_5','Industry Experts\n(Pharma & Health)','text','participants','Participant Type 5','2026-08-19 04:16:38','2026-08-19 04:16:38'),(35,'workshop_title','Hands-On Metagenomics','text','workshop','Main Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(36,'workshop_desc','Join us for an exclusive one-day hands-on workshop on the day before the main conference. Participants will gain practical skills in metagenomic data analysis—from quality control and community profiling to assembly and visualization using tools like QIIME2 and relevant datasets.\n\nPerfect for students, researchers, and faculty looking to strengthen their bioinformatics toolkit.','textarea','workshop','Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(37,'workshop_f1_title','Practical Skills','text','workshop','Feature 1 Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(38,'workshop_f1_desc','Learn quality control, community profiling, and assembly.','text','workshop','Feature 1 Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(39,'workshop_f2_title','Industry Tools','text','workshop','Feature 2 Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(40,'workshop_f2_desc','Hands-on visualization using tools like QIIME2 and real datasets.','text','workshop','Feature 2 Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(41,'workshop_f3_title','Bioinformatics Toolkit','text','workshop','Feature 3 Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(42,'workshop_f3_desc','Designed specifically for students, researchers, and faculty.','text','workshop','Feature 3 Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(43,'thrust_areas_desc','Explore the latest advancements, critical challenges, and future innovations across our core diagnostic and scientific themes.','textarea','thrust_areas','Section Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(44,'thrust_1','Artificial intelligence in infectious disease diagnostics','text','thrust_areas','Theme 1','2026-08-19 04:16:38','2026-08-19 04:16:38'),(45,'thrust_2','AI in diagnostic microbiology','text','thrust_areas','Theme 2','2026-08-19 04:16:38','2026-08-19 04:16:38'),(46,'thrust_3','Molecular diagnostics and genomics','text','thrust_areas','Theme 3','2026-08-19 04:16:38','2026-08-19 04:16:38'),(47,'thrust_4','Digital health and intelligent systems','text','thrust_areas','Theme 4','2026-08-19 04:16:38','2026-08-19 04:16:38'),(48,'thrust_5','Clinical applications and future directions','text','thrust_areas','Theme 5','2026-08-19 04:16:38','2026-08-19 04:16:38'),(49,'thrust_6','Antimicrobial resistance and rapid detection','text','thrust_areas','Theme 6','2026-08-19 04:16:38','2026-08-19 04:16:38'),(50,'thrust_7','Emerging infectious diseases','text','thrust_areas','Theme 7','2026-08-19 04:16:38','2026-08-19 04:16:38'),(51,'thrust_8','Point-of-care diagnostics','text','thrust_areas','Theme 8','2026-08-19 04:16:38','2026-08-19 04:16:38'),(52,'thrust_9','Clinical case studies','text','thrust_areas','Theme 9','2026-08-19 04:16:38','2026-08-19 04:16:38'),(53,'abstract_desc_1','Abstracts are invited for original research work that has not been published or submitted elsewhere.','textarea','abstract','Description Paragraph 1','2026-08-19 04:16:38','2026-08-19 04:16:38'),(54,'abstract_desc_2','Students, research scholars, faculty members, and industry participants may submit abstracts for <strong>oral and/or poster presentations</strong>.','textarea','abstract','Description Paragraph 2','2026-08-19 04:16:38','2026-08-19 04:16:38'),(55,'abstract_req_font','Times New Roman, Size 12','text','abstract','Font Requirement','2026-08-19 04:16:38','2026-08-19 04:16:38'),(56,'abstract_req_spacing','1.5 line spacing','text','abstract','Spacing Requirement','2026-08-19 04:16:38','2026-08-19 04:16:38'),(57,'abstract_req_length','Maximum of 250 words','text','abstract','Length Requirement','2026-08-19 04:16:38','2026-08-19 04:16:38'),(58,'abstract_req_keywords','Maximum of 5 keywords','text','abstract','Keywords Requirement','2026-08-19 04:16:38','2026-08-19 04:16:38'),(59,'awards_desc','To recognize outstanding research contributions, we are proud to present awards for the most exceptional presentations at the summit.','textarea','awards','Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(60,'awards_oral_title','Best Oral Presentation','text','awards','Oral Award Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(61,'awards_oral_desc','Awarded to the most impactful and articulate oral research presentation.','text','awards','Oral Award Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(62,'awards_poster_title','Best Poster Award','text','awards','Poster Award Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(63,'awards_poster_desc','Awarded for outstanding visual communication and scientific clarity.','text','awards','Poster Award Description','2026-08-19 04:16:38','2026-08-19 04:16:38'),(64,'venue_discover_title','Discover Madras Christian College','text','venue','Discover Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(65,'venue_discover_text','Founded in 1837, Madras Christian College (MCC) is one of Asia\'s oldest and most prestigious academic institutions. Set within a sprawling, lush 320-acre scrub jungle campus in Tambaram, Chennai, MCC offers a serene, intellectually stimulating environment that provides a perfect backdrop for international conferences, global collaboration, and cutting-edge scientific exchange.','textarea','venue','Discover Text','2026-08-19 04:16:38','2026-08-19 04:16:38'),(66,'venue_heritage_title','A Hub of Heritage & Innovation','text','venue','Heritage Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(67,'venue_heritage_text','MCC seamlessly blends a rich historical legacy with modern scientific inquiry. With a profound history of producing renowned scholars, researchers, and global leaders, the institution continues to foster excellence. Its proximity to prominent research hubs in Chennai and its own state-of-the-art facilities make it an ideal meeting point for the BioMed Summit 2027.','textarea','venue','Heritage Text','2026-08-19 04:16:38','2026-08-19 04:16:38'),(68,'venue_biodiversity_title','Campus Biodiversity & Environment','text','venue','Biodiversity Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(69,'venue_biodiversity_text','The MCC campus is a documented sanctuary of rare flora and fauna, providing delegates with a refreshing escape from the urban hustle. During the conference, attendees can enjoy:','textarea','venue','Biodiversity Text','2026-08-19 04:16:38','2026-08-19 04:16:38'),(70,'venue_biodiversity_list','Exploring the expansive, protected scrub jungle ecosystem\nHistoric British-era architectural landmarks seamlessly integrated with modern halls\nA tranquil, pollution-free atmosphere ideal for focused scientific networking\nThe vibrant cultural heritage and traditional South Indian hospitality of Chennai','textarea','venue','Biodiversity Bullets (One per line)','2026-08-19 04:16:38','2026-08-19 04:16:38'),(71,'venue_accessibility_title','Easy Accessibility','text','venue','Accessibility Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(72,'venue_accessibility_text','Located in the bustling metropolis of Chennai, MCC is exceptionally well-connected. It is easily accessible via the Chennai International Airport (MAA), which offers direct flights worldwide. Furthermore, the Tambaram Railway Station and major transit hubs are situated directly opposite the campus, ensuring seamless domestic and international travel for all delegates.','textarea','venue','Accessibility Text','2026-08-19 04:16:38','2026-08-19 04:16:38'),(73,'venue_facilities_title','World-Class Conference Facilities','text','venue','Facilities Title','2026-08-19 04:16:38','2026-08-19 04:16:38'),(74,'venue_facilities_text','MCC boasts a wide array of premium venues, including historic grand auditoriums and highly equipped modern smart-halls. With advanced audio-visual technology, high-speed connectivity, and spacious seating, the campus provides a highly professional, comfortable, and accommodating environment for large-scale plenary sessions and specialized workshops alike.','textarea','venue','Facilities Text','2026-08-19 04:16:38','2026-08-19 04:16:38'),(75,'awards_intro','At Biomed Summit, we celebrate the spirit of research, innovation, and academic excellence. To foster advancement and honor exceptional contributions, we proudly present the Conference Awards to outstanding researchers, scholars, and innovators.','textarea','awards_page','Intro Paragraph','2026-08-19 04:16:38','2026-08-19 04:16:38'),(76,'sponsors_intro','Partnering with us as a sponsor or exhibitor gives your organization a unique opportunity to stand at the forefront of global innovation. Our international summits connect you directly with leading researchers, decision-makers, and industry pioneers — offering high-value visibility, strategic networking, and brand credibility. From showcasing your latest innovations to forging meaningful collaborations, this is your chance to amplify your impact, generate quality leads, and position your brand where the future is being shaped.','textarea','sponsors','Intro Paragraph','2026-08-19 04:16:38','2026-08-19 04:16:38'),(77,'sponsors_benefits','Enhance your brand visibility among international audiences\nShowcase your technologies, products, or services to leading institutions and professionals\nConnect directly with key decision-makers and industry influencers\nBuild global partnerships and collaborative networks\nParticipate in high-value networking sessions, panels, and technical discussions\nReceive branding across digital, print, and on-site materials\nGenerate qualified leads and accelerate business development\nEstablish your brand as a thought leader in your industry','textarea','sponsors','Key Benefits','2026-08-19 04:16:38','2026-08-19 04:16:38'),(78,'hero_bg_image','images/hero-bg.png','image','hero','Hero Background Image','2026-08-19 06:27:37','2026-08-19 06:27:37'),(79,'objectives_desc','The Global One Health Confluence 2026 brings together leaders in science, policy, and practice to address our most pressing health challenges through a unified interdisciplinary approach.','textarea','objectives','Section Description','2026-08-19 06:31:24','2026-08-19 06:31:24'),(80,'obj_1_title','Promote Interdisciplinary Collaboration','text','objectives','Objective 1 Title','2026-08-19 06:31:24','2026-10-05 01:01:11'),(81,'obj_1_desc','To promote interdisciplinary collaboration across microbiology, health and sustainability.','textarea','objectives','Objective 1 Description','2026-08-19 06:31:24','2026-10-05 01:01:11'),(82,'obj_2_title','Discuss Emerging Challenges','text','objectives','Objective 2 Title','2026-08-19 06:31:24','2026-10-05 01:01:11'),(83,'obj_2_desc','To discuss emerging challenges and innovative solutions through global scientific discourse.','textarea','objectives','Objective 2 Description','2026-08-19 06:31:24','2026-10-05 01:01:11'),(84,'obj_3_title','Encourage Research Translation','text','objectives','Objective 3 Title','2026-08-19 06:31:24','2026-10-05 01:01:11'),(85,'obj_3_desc','To encourage research translation for real-world applications and impact.','textarea','objectives','Objective 3 Description','2026-08-19 06:31:24','2026-10-05 01:01:11'),(86,'obj_4_title','Foster Global Partnerships','text','objectives','Objective 4 Title','2026-08-19 06:31:24','2026-10-05 01:01:11'),(87,'obj_4_desc','To foster global partnerships for a One Health and sustainable future.','textarea','objectives','Objective 4 Description','2026-08-19 06:31:24','2026-10-05 01:01:11'),(88,'pillars_title','Five Pillars of the Confluence','text','pillars','Section Title','2026-08-19 06:39:07','2026-08-19 06:39:07'),(89,'pillars_subtitle','Interdisciplinary framework driving sustainable global health through science, policy & partnership','textarea','pillars','Section Subtitle','2026-08-19 06:39:07','2026-08-19 06:39:07'),(90,'pillar_1_tag','Research','text','pillars','Pillar 1 Tag','2026-08-19 06:39:07','2026-08-19 06:39:07'),(91,'pillar_1_title','Scientific Excellence','text','pillars','Pillar 1 Title','2026-08-19 06:39:07','2026-08-19 06:39:07'),(92,'pillar_1_desc','Facilitating high-quality interdisciplinary scientific discourse spanning microbiology, chemistry, biotechnology, environmental sciences, public health, and molecular medicine.','textarea','pillars','Pillar 1 Description','2026-08-19 06:39:07','2026-08-19 06:39:07'),(93,'pillar_1_icon','fa-solid fa-microscope','text','pillars','Pillar 1 Icon','2026-08-19 06:39:07','2026-10-05 01:01:11'),(94,'pillar_2_tag','Innovation','text','pillars','Pillar 2 Tag','2026-08-19 06:39:07','2026-08-19 06:39:07'),(95,'pillar_2_title','Translational Innovation','text','pillars','Pillar 2 Title','2026-08-19 06:39:07','2026-08-19 06:39:07'),(96,'pillar_2_desc','Promoting research translation through biotechnology, diagnostics, biosensors, sustainable chemistry, advanced materials, green technologies, and circular bioeconomy.','textarea','pillars','Pillar 2 Description','2026-08-19 06:39:07','2026-08-19 06:39:07'),(97,'pillar_2_icon','fa-solid fa-flask-vial','text','pillars','Pillar 2 Icon','2026-08-19 06:39:07','2026-08-19 06:39:07'),(98,'pillar_3_tag','Policy','text','pillars','Pillar 3 Tag','2026-08-19 06:39:07','2026-08-19 06:39:07'),(99,'pillar_3_title','Policy & Governance','text','pillars','Pillar 3 Title','2026-08-19 06:39:07','2026-08-19 06:39:07'),(100,'pillar_3_desc','Strengthening dialogue among researchers, policymakers, governmental agencies, and international organizations for evidence-informed health governance.','textarea','pillars','Pillar 3 Description','2026-08-19 06:39:07','2026-08-19 06:39:07'),(101,'pillar_3_icon','fa-solid fa-scale-balanced','text','pillars','Pillar 3 Icon','2026-08-19 06:39:07','2026-08-19 06:39:07'),(102,'pillar_4_tag','Heritage','text','pillars','Pillar 4 Tag','2026-08-19 06:39:07','2026-08-19 06:39:07'),(103,'pillar_4_title','Indigenous Integration','text','pillars','Pillar 4 Title','2026-08-19 06:39:07','2026-08-19 06:39:07'),(104,'pillar_4_desc','Exploring the role of Indian Knowledge Systems and traditional healthcare practices in complementing modern One Health approaches.','textarea','pillars','Pillar 4 Description','2026-08-19 06:39:07','2026-08-19 06:39:07'),(105,'pillar_4_icon','fa-solid fa-leaf','text','pillars','Pillar 4 Icon','2026-08-19 06:39:07','2026-08-19 06:39:07'),(106,'pillar_5_tag','Network','text','pillars','Pillar 5 Tag','2026-08-19 06:39:07','2026-08-19 06:39:07'),(107,'pillar_5_title','Global Partnerships','text','pillars','Pillar 5 Title','2026-08-19 06:39:07','2026-08-19 06:39:07'),(108,'pillar_5_desc','Building long-term collaborative networks among academia, healthcare, industry, research institutions, and international organizations.','textarea','pillars','Pillar 5 Description','2026-08-19 06:39:07','2026-08-19 06:39:07'),(109,'pillar_5_icon','fa-solid fa-earth-americas','text','pillars','Pillar 5 Icon','2026-08-19 06:39:07','2026-08-19 06:39:07'),(110,'hero_btn1_text','REGISTER NOW','text','hero','Primary Button Text','2026-08-19 23:26:45','2026-08-19 23:29:16'),(111,'hero_btn1_link','/registration','text','hero','Primary Button Link','2026-08-19 23:26:45','2026-08-19 23:29:16'),(112,'hero_btn2_text','APPLY FOR AWARDS','text','hero','Secondary Button Text','2026-08-19 23:26:45','2026-10-06 06:43:26'),(113,'hero_btn2_link','/awards','text','hero','Secondary Button Link','2026-08-19 23:26:45','2026-10-06 06:43:26'),(114,'obj_5_title','Knowledge Exchange','text','objectives','Objective 5 Title','2026-09-02 23:44:45','2026-09-07 05:05:39'),(115,'obj_5_desc','Provide a platform for knowledge exchange and networking, empowering researchers, students and innovators to showcase impactful research.','textarea','objectives','Objective 5 Description','2026-09-02 23:44:45','2026-09-02 23:44:45'),(116,'org_section_subtitle','About The Organizers','text','about_organizer','Section Subtitle','2026-09-07 04:18:03','2026-09-07 04:18:03'),(117,'org_section_title','Host Institutions & Departments','text','about_organizer','Section Title','2026-09-07 04:18:03','2026-09-07 04:18:03'),(118,'mcc_tab_title','Madras Christian College','text','about_organizer','MCC Tab Nav Title','2026-09-07 04:18:03','2026-09-07 04:18:03'),(119,'mcc_tab_sub','MCC • Chennai','text','about_organizer','MCC Tab Nav Subtitle','2026-09-07 04:18:03','2026-09-07 04:18:03'),(120,'mcc_tag','Madras Christian College','text','about_organizer','MCC Tagline','2026-09-07 04:18:03','2026-09-07 04:18:03'),(121,'mcc_title','A Legacy of Academic Excellence','text','about_organizer','MCC Title','2026-09-07 04:18:03','2026-09-07 04:18:03'),(122,'mcc_p1','Madras Christian College (MCC), established in 1837, is one of India\'s premier institutions of higher learning with a rich heritage of academic excellence, character formation and nation building.','textarea','about_organizer','MCC Paragraph 1','2026-09-07 04:18:03','2026-09-07 04:18:03'),(123,'mcc_p2','Affiliated to the University of Madras and accredited with \'A\' Grade by NAAC, MCC offers a vibrant environment for holistic education across disciplines.','textarea','about_organizer','MCC Paragraph 2','2026-09-07 04:18:03','2026-09-07 04:18:03'),(124,'mcc_p3','The Department of Microbiology at MCC has a strong legacy of quality teaching, innovative research and contributions to the advancement of microbial sciences with a focus on societal impact and global relevance.','textarea','about_organizer','MCC Paragraph 3','2026-09-07 04:18:03','2026-09-07 04:18:03'),(125,'mcc_feat1_title','ESTABLISHED IN 1837','text','about_organizer','Highlight 1 Title','2026-09-07 04:18:03','2026-09-07 04:18:03'),(126,'mcc_feat1_sub','A legacy of 189 years of academic excellence','text','about_organizer','Highlight 1 Subtitle','2026-09-07 04:18:03','2026-09-07 04:18:03'),(127,'mcc_feat1_icon','fa-solid fa-landmark','text','about_organizer','Highlight 1 Icon','2026-09-07 04:18:03','2026-09-07 04:18:03'),(128,'mcc_feat2_title','\'A\' GRADE BY NAAC','text','about_organizer','Highlight 2 Title','2026-09-07 04:18:03','2026-09-07 04:18:03'),(129,'mcc_feat2_sub','Recognized for quality and institutional excellence','text','about_organizer','Highlight 2 Subtitle','2026-09-07 04:18:03','2026-09-07 04:18:03'),(130,'mcc_feat2_icon','fa-solid fa-award','text','about_organizer','Highlight 2 Icon','2026-09-07 04:18:03','2026-09-07 04:18:03'),(131,'mcc_feat3_title','AUTONOMOUS INSTITUTION','text','about_organizer','Highlight 3 Title','2026-09-07 04:18:03','2026-09-07 04:18:03'),(132,'mcc_feat3_sub','Affiliated to the University of Madras','text','about_organizer','Highlight 3 Subtitle','2026-09-07 04:18:03','2026-09-07 04:18:03'),(133,'mcc_feat3_icon','fa-solid fa-graduation-cap','text','about_organizer','Highlight 3 Icon','2026-09-07 04:18:04','2026-09-07 04:18:04'),(134,'mcc_feat4_title','HOLISTIC EDUCATION','text','about_organizer','Highlight 4 Title','2026-09-07 04:18:04','2026-09-07 04:18:04'),(135,'mcc_feat4_sub','Nurturing intellect, character and leadership','text','about_organizer','Highlight 4 Subtitle','2026-09-07 04:18:04','2026-09-07 04:18:04'),(136,'mcc_feat4_icon','fa-solid fa-users','text','about_organizer','Highlight 4 Icon','2026-09-07 04:18:04','2026-09-07 04:18:04'),(137,'mcc_feat5_title','RESEARCH & INNOVATION','text','about_organizer','Highlight 5 Title','2026-09-07 04:18:04','2026-09-07 04:18:04'),(138,'mcc_feat5_sub','Encouraging impactful research for a better world','text','about_organizer','Highlight 5 Subtitle','2026-09-07 04:18:04','2026-09-07 04:18:04'),(139,'mcc_feat5_icon','fa-solid fa-microscope','text','about_organizer','Highlight 5 Icon','2026-09-07 04:18:04','2026-09-07 04:18:04'),(140,'mmip_tab_title','MCC-MRF Innovation Park','text','about_organizer','MMIP Tab Nav Title','2026-09-07 04:18:04','2026-09-07 04:18:04'),(141,'mmip_tab_sub','MMIP','text','about_organizer','MMIP Tab Nav Subtitle','2026-09-07 04:18:04','2026-09-07 04:18:04'),(142,'mmip_tag','MCC-MRF Innovation Park','text','about_organizer','MMIP Tagline','2026-09-07 04:18:04','2026-09-07 04:18:04'),(143,'mmip_title','A Pioneering Innovation Ecosystem','text','about_organizer','MMIP Title','2026-09-07 04:18:04','2026-09-07 04:18:04'),(144,'mmip_p1','MCC–MRF Innovation Park (MMIP), established at Madras Christian College with the generous support of the MRF Foundation, is a pioneering innovation ecosystem dedicated to research, innovation, entrepreneurship, and startup development. Spread across 45,000 sq. ft., MMIP is the largest innovation park among liberal arts and science colleges in India, and one of the first-of-its-kind innovation parks established within a liberal arts and science institution.','textarea','about_organizer','MMIP Paragraph 1','2026-09-07 04:18:04','2026-09-07 04:18:04'),(145,'mmip_p2','MMIP integrates research, design thinking, technology, and entrepreneurship into a multidisciplinary academic environment, demonstrating that innovation can flourish across disciplines beyond engineering. It serves as a scalable model for higher education institutions seeking to promote innovation-driven education, interdisciplinary collaboration, and entrepreneurial thinking.','textarea','about_organizer','MMIP Paragraph 2','2026-09-07 04:18:04','2026-09-07 04:18:04'),(146,'micro_tab_title','Dept. of Microbiology','text','about_organizer','Microbiology Tab Nav Title','2026-09-07 04:18:04','2026-09-07 04:18:04'),(147,'micro_tab_sub','Est. 2002 • Research Unit','text','about_organizer','Microbiology Tab Nav Subtitle','2026-09-07 04:18:04','2026-09-07 04:18:04'),(148,'micro_tag','Madras Christian College','text','about_organizer','Microbiology Tagline','2026-09-07 04:18:04','2026-09-07 04:18:04'),(149,'micro_title','Department of Microbiology','text','about_organizer','Microbiology Title','2026-09-07 04:18:04','2026-09-07 04:18:04'),(150,'chem_tab_title','Dept. of Chemistry (SFS)','text','about_organizer','Chemistry Tab Nav Title','2026-09-07 04:18:04','2026-09-07 04:18:04'),(151,'chem_tab_sub','Est. 2003 • M.Sc. Program','text','about_organizer','Chemistry Tab Nav Subtitle','2026-09-07 04:18:04','2026-09-07 04:18:04'),(152,'chem_tag','Madras Christian College','text','about_organizer','Chemistry Tagline','2026-09-07 04:18:04','2026-09-07 04:18:04'),(153,'chem_title','Department of Chemistry (SFS)','text','about_organizer','Chemistry Title','2026-09-07 04:18:04','2026-09-07 04:18:04'),(154,'objectives_section_title','Conference Objectives','text','objectives','Section Title','2026-09-07 05:05:39','2026-09-07 05:05:39'),(155,'obj_1_icon','fa-solid fa-sitemap','text','objectives','Objective 1 Icon','2026-09-07 05:05:39','2026-09-07 05:05:39'),(156,'obj_2_icon','fa-solid fa-globe','text','objectives','Objective 2 Icon','2026-09-07 05:05:39','2026-09-07 05:05:39'),(157,'obj_3_icon','fa-solid fa-leaf','text','objectives','Objective 3 Icon','2026-09-07 05:05:39','2026-09-07 05:05:39'),(158,'obj_4_icon','fa-solid fa-handshake','text','objectives','Objective 4 Icon','2026-09-07 05:05:39','2026-09-07 05:05:39'),(159,'obj_5_icon','fa-solid fa-lightbulb','text','objectives','Objective 5 Icon','2026-09-07 05:05:39','2026-09-07 05:05:39'),(160,'highlights_title','Conference Highlights','text','highlights','Highlights Title','2026-09-07 05:25:54','2026-09-07 05:25:54'),(161,'highlights_subtitle','Key features and interactive forums scheduled for the Global One Health Confluence 2026','text','highlights','Highlights Subtitle','2026-09-07 05:25:54','2026-09-07 05:25:54'),(162,'pub_title','Scientific Publications','text','highlights','Publications Title','2026-09-07 05:25:54','2026-09-15 06:30:21'),(163,'pub_subtitle','Selected peer-reviewed manuscripts will be considered for publication in:','text','highlights','Publications Subtitle','2026-09-07 05:25:54','2026-09-07 05:25:54'),(164,'pub_item_1','All the Presentation will be published as a conference proceedings in ISBN indexed book','text','highlights','Publication Item 1','2026-09-07 05:25:54','2026-10-06 06:41:28'),(165,'pub_item_2','Quality presentation will be peer reviewed and considered for further publication in selected Scopus/ WoS indexed journals','text','highlights','Publication Item 2','2026-09-07 05:25:54','2026-10-06 06:41:28'),(167,'part_tag','WHO CAN ATTEND','text','participants','Section Tagline','2026-09-07 05:25:55','2026-09-07 05:25:55'),(168,'part_title','Our Participants','text','participants','Section Title','2026-09-07 05:25:55','2026-09-07 05:25:55'),(169,'part_sub','Join the confluence to bridge microbes, molecules & mankind for a sustainable future.','text','participants','Section Subtitle','2026-09-07 05:25:55','2026-09-07 05:25:55'),(170,'part_1_label','Students &\nResearch Scholars','text','participants','Participant 1 Label','2026-09-07 05:25:55','2026-09-07 05:25:55'),(171,'part_1_icon','fa-solid fa-graduation-cap','text','participants','Participant 1 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(172,'part_2_label','Academicians &\nPolicy Makers','text','participants','Participant 2 Label','2026-09-07 05:25:55','2026-09-07 05:25:55'),(173,'part_2_icon','fa-solid fa-microscope','text','participants','Participant 2 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(174,'part_3_label','Research\nScientists','text','participants','Participant 3 Label','2026-09-07 05:25:55','2026-09-07 05:25:55'),(175,'part_3_icon','fa-solid fa-flask','text','participants','Participant 3 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(176,'part_4_label','Health\nProfessionals','text','participants','Participant 4 Label','2026-09-07 05:25:55','2026-09-07 05:25:55'),(177,'part_4_icon','fa-solid fa-book-open-reader','text','participants','Participant 4 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(178,'part_5_label','Industry Experts (Pharma\n& Health)','text','participants','Participant 5 Label','2026-09-07 05:25:55','2026-09-07 05:25:55'),(179,'part_5_icon','fa-solid fa-industry','text','participants','Participant 5 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(180,'outcomes_title','Key Expected Outcomes','text','outcomes','Outcomes Section Title','2026-09-07 05:25:55','2026-09-07 05:25:55'),(181,'outcomes_sub','Tangible impacts and key deliverables driving the Global One Health vision forward through innovation, policy, and education.','text','outcomes','Outcomes Section Subtitle','2026-09-07 05:25:55','2026-09-07 05:25:55'),(182,'out_1_tag','Collaboration','text','outcomes','Outcome 1 Tag','2026-09-07 05:25:55','2026-09-07 05:25:55'),(183,'out_1_title','Strengthened interdisciplinary collaborations','text','outcomes','Outcome 1 Title','2026-09-07 05:25:55','2026-09-07 05:25:55'),(184,'out_1_icon','fa-solid fa-users-gear','text','outcomes','Outcome 1 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(185,'out_2_tag','Global','text','outcomes','Outcome 2 Tag','2026-09-07 05:25:55','2026-09-07 05:25:55'),(186,'out_2_title','International research partnerships','text','outcomes','Outcome 2 Title','2026-09-07 05:25:55','2026-09-07 05:25:55'),(187,'out_2_icon','fa-solid fa-globe','text','outcomes','Outcome 2 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(188,'out_3_tag','Research','text','outcomes','Outcome 3 Tag','2026-09-07 05:25:55','2026-09-07 05:25:55'),(189,'out_3_title','High-quality scientific publications','text','outcomes','Outcome 3 Title','2026-09-07 05:25:55','2026-09-07 05:25:55'),(190,'out_3_icon','fa-solid fa-book-bookmark','text','outcomes','Outcome 3 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(191,'out_4_tag','Innovation','text','outcomes','Outcome 4 Tag','2026-09-07 05:25:55','2026-09-07 05:25:55'),(192,'out_4_title','Translation of research into innovation','text','outcomes','Outcome 4 Title','2026-09-07 05:25:55','2026-09-07 05:25:55'),(193,'out_4_icon','fa-solid fa-lightbulb','text','outcomes','Outcome 4 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(194,'out_5_tag','Policy','text','outcomes','Outcome 5 Tag','2026-09-07 05:25:55','2026-09-07 05:25:55'),(195,'out_5_title','Policy recommendations for One Health','text','outcomes','Outcome 5 Title','2026-09-07 05:25:55','2026-09-07 05:25:55'),(196,'out_5_icon','fa-solid fa-landmark','text','outcomes','Outcome 5 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(197,'out_6_tag','Education','text','outcomes','Outcome 6 Tag','2026-09-07 05:25:55','2026-09-07 05:25:55'),(198,'out_6_title','Capacity building for early-career researchers','text','outcomes','Outcome 6 Title','2026-09-07 05:25:55','2026-09-07 05:25:55'),(199,'out_6_icon','fa-solid fa-graduation-cap','text','outcomes','Outcome 6 Icon','2026-09-07 05:25:55','2026-09-07 05:25:55'),(200,'journey_title','Our Journey to Impact','text','journey','Journey Section Title','2026-09-07 05:55:15','2026-09-07 05:55:15'),(201,'journey_sub','A strategic 4-step pathway driving global collaboration into sustainable transformation.','text','journey','Journey Section Subtitle','2026-09-07 05:55:15','2026-09-07 05:55:15'),(202,'journey_1_title','CONNECT','text','journey','Step 1 Title','2026-09-07 05:55:15','2026-09-07 05:55:15'),(203,'journey_1_desc','Bringing global minds together for meaningful collaboration.','textarea','journey','Step 1 Description','2026-09-07 05:55:15','2026-09-07 05:55:15'),(204,'journey_2_title','SHARE','text','journey','Step 2 Title','2026-09-07 05:55:15','2026-09-07 05:55:15'),(205,'journey_2_desc','Sharing knowledge, innovations and best practices.','textarea','journey','Step 2 Description','2026-09-07 05:55:15','2026-09-07 05:55:15'),(206,'journey_3_title','INNOVATE','text','journey','Step 3 Title','2026-09-07 05:55:15','2026-09-07 05:55:15'),(207,'journey_3_desc','Creating solutions for a healthier planet and resilient communities.','textarea','journey','Step 3 Description','2026-09-07 05:55:15','2026-09-07 05:55:15'),(208,'journey_4_title','IMPACT','text','journey','Step 4 Title','2026-09-07 05:55:15','2026-09-07 05:55:15'),(209,'journey_4_desc','Driving sustainable change for generations to come.','textarea','journey','Step 4 Description','2026-09-07 05:55:15','2026-09-07 05:55:15'),(210,'abstract_tag','PRIMARY GUIDELINES','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(211,'abstract_title','Abstract Submission','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(212,'abstract_item_1','Abstracts should be original and highly relevant to the conference themes.','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(213,'abstract_item_2','Word Limit: Strictly 250–300 words','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(214,'abstract_item_3','Format Structure: Title, Authors, Affiliation, Background, Objectives, Methods, Results, Conclusion, Keywords','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(215,'abstract_item_4','File Type: Submit exclusively in MS Word format (.doc or .docx)','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(216,'abstract_item_5','Registration: Presenting author must register for the conference.','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(217,'abstract_item_6','Review Process: All abstracts will undergo a rigorous peer review.','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(218,'oral_title','Oral Presentation','text','guidelines',NULL,'2026-09-07 06:06:31','2026-09-07 06:06:31'),(219,'oral_item_1','Format: PowerPoint Presentation (PPT) format only','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(220,'oral_item_2','Total Time: 7 Minutes maximum','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(221,'oral_item_3','Presentation Window: 5 Minutes','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(222,'oral_item_4','Q & A Session: 2 Minutes allocated for audience questions','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(223,'poster_title','Poster Presentation','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(224,'poster_item_1','Language: Posters should be presented in English.','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(225,'poster_item_2','Design: Content must be clear, concise and visually appealing.','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(226,'poster_item_3','Required Elements: Title, Authors, Affiliation, Introduction, Methods, Results, Conclusion.','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(227,'poster_item_4','Attendance: Presenters must be present during the poster session.','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(228,'poster_dim_label','POSTER DIMENSIONS','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(229,'poster_dim_val','90 cm (Width) × 120 cm (Height)','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(230,'pub_desc','Selected peer-reviewed manuscripts will be considered for publication in our partnering international journals and indexed proceedings, offering global visibility for your research.','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(231,'pub_1_title','Scopus-Indexed Journals','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(232,'pub_1_desc','Manuscripts meeting high academic standards will be recommended for fast-track publication in recognized Scopus-indexed journals.','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(233,'pub_2_title','ISBN Proceedings','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(234,'pub_2_desc','Accepted abstracts and short papers will be compiled and published in official edited conference proceedings with a registered ISBN.','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(235,'pub_3_title','Special Issues','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(236,'pub_3_desc','Exceptional papers may be selected for special thematic issues with partnering international journals, subject to standard peer-review.','text','guidelines',NULL,'2026-09-07 06:06:32','2026-09-07 06:06:32'),(250,'reg_section_title','Registration Plans','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(251,'reg_section_sub','Choose the appropriate registration tier to access the conference. Super early-bird rates are currently active.','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(252,'reg_proc_title','Registration Process of GOHC - 2026','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(253,'reg_proc_sub','Participation in GOHC 2026 is open only to registered delegates..','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(254,'reg_proc_heading','Steps for Conference Registration','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(255,'reg_step_1','Prepare your abstract using the official template available on the conference website or by scanning the provided QR code.','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(256,'reg_step_2','Pay the applicable registration fee using the provided payment link.','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(257,'reg_step_3','Download and save the payment receipt in PDF or JPG format, as it is required for registration.','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(258,'reg_step_4','Complete the online registration form using the provided registration link.','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(259,'reg_step_5','Submit the registration form along with your abstract to complete the registration process.','text','registration',NULL,'2026-09-07 06:17:54','2026-09-07 06:17:54'),(260,'sched_title','PROGRAMME SCHEDULE','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(261,'sched_sub','Complete schedule of sessions, guest lectures, and presentations for Day 1 and Day 2.','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(262,'sched_day1_title','DAY – I SCHEDULE','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(263,'sched_day1_time','9:30 AM – 6:00 PM','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(264,'sched_day2_title','DAY – II SCHEDULE','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(265,'sched_day2_time','9:30 AM – 5:30 PM','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(266,'sched_tracks_title','TRACK-WISE INCHARGE','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(267,'sched_tracks_sub','Parallel technical tracks covering specialized domains of Global One Health Confluence 2026.','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(268,'day1_1_time','9:30 AM – 11:30 AM','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(269,'day1_1_title','Inauguration','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(270,'day1_1_badge','','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(271,'day1_1_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(272,'day1_2_time','11:30 AM – 11:45 AM','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(273,'day1_2_title','Tea Break','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(274,'day1_2_badge','Refreshment','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(275,'day1_2_icon','fa-mug-hot','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(276,'day1_3_time','11:45 AM – 12:30 PM','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(277,'day1_3_title','Guest Lecture - I','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(278,'day1_3_badge','','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(279,'day1_3_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(280,'day1_4_time','12:30 PM – 1:15 PM','text','schedule',NULL,'2026-09-07 06:37:17','2026-09-07 06:37:17'),(281,'day1_4_title','Guest Lecture - II','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(282,'day1_4_badge','','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(283,'day1_4_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(284,'day1_5_time','1:15 PM – 2:15 PM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(285,'day1_5_title','Lunch Break','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(286,'day1_5_badge','Break','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(287,'day1_5_icon','fa-utensils','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(288,'day1_6_time','2:15 PM – 3:00 PM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(289,'day1_6_title','Guest Lecture - III','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(290,'day1_6_badge','','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(291,'day1_6_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(292,'day1_7_time','3:00 PM – 6:00 PM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(293,'day1_7_title','Paper Presentation - Tracks I, II & III','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(294,'day1_7_badge','Parallel Session','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(295,'day1_7_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(296,'day1_8_time','3:00 PM – 6:00 PM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(297,'day1_8_title','Poster Presentation - Tracks I, II & III','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(298,'day1_8_badge','Parallel Session','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(299,'day1_8_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(300,'day1_count','8','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(301,'day2_1_time','9:30 AM – 10:15 AM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(302,'day2_1_title','Guest Lecture - IV','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(303,'day2_1_badge','','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(304,'day2_1_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(305,'day2_2_time','10:15 AM – 11:00 AM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(306,'day2_2_title','Guest Lecture - V','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(307,'day2_2_badge','','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(308,'day2_2_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(309,'day2_3_time','11:00 AM – 11:15 AM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(310,'day2_3_title','Tea Break','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(311,'day2_3_badge','Refreshment','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(312,'day2_3_icon','fa-mug-hot','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(313,'day2_4_time','11:15 AM – 1:15 PM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(314,'day2_4_title','Oral & Poster Presentations - Tracks IV & V','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(315,'day2_4_badge','Parallel Session','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(316,'day2_4_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(317,'day2_5_time','1:15 PM – 2:15 PM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(318,'day2_5_title','Lunch Break','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(319,'day2_5_badge','Break','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(320,'day2_5_icon','fa-utensils','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(321,'day2_6_time','2:15 PM – 3:30 PM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(322,'day2_6_title','Guest Lecture - VI & Panel Discussion','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(323,'day2_6_badge','','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(324,'day2_6_icon','fa-clock','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(325,'day2_7_time','3:30 PM – 4:30 PM','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(326,'day2_7_title','Valedictory & Award Ceremony','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(327,'day2_7_badge','Special Event','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(328,'day2_7_icon','fa-trophy','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(329,'day2_count','7','text','schedule',NULL,'2026-09-07 06:37:18','2026-09-07 06:37:18'),(347,'awards_section_title','Distinguished Awards','text','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(348,'awards_section_sub','Celebrating exceptional scholastic achievements, research excellence, and entrepreneurial vision with cash prizes and distiction.','textarea','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(349,'award_1_title','Faculty Award for excellence in\r\nOne Health research','textarea','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(350,'award_1_amount','₹ 25,000','text','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(351,'award_1_icon','fa-solid fa-award','text','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(352,'award_2_title','One Health Distinguished\r\nResearch Scholar Award','textarea','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(353,'award_2_amount','₹ 10,000','text','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(354,'award_2_icon','fa-solid fa-award','text','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(355,'award_3_title','Young Innovator &\r\nEntrepreneur Award','textarea','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(356,'award_3_amount','₹ 25,000','text','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(357,'award_3_icon','fa-solid fa-award','text','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(358,'awards_footer_note','Prizes will be awarded for best Oral, Poster\r\nPresentations and Best Innovation Pitch','textarea','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(359,'awards_footer_icon','fa-solid fa-file-excel','text','awards_page',NULL,'2026-09-08 04:33:58','2026-10-05 04:13:21'),(360,'footer_copyright','©2026 GLOBAL ONE HEALTH CONFLUENCE Design and Developed by MCC-MRF Innovation Park','text','footer','Copyright Text',NULL,NULL),(389,'pre_conf_preamble','The Pre-Conference Consultation of Global One Health Confluence 2026 aims to bring together eminent experts, academicians, researchers, healthcare professionals, policymakers and resource persons from diverse disciplines to provide focused and meaningful inputs for the scientific, thematic and collaborative planning of the conference. The consultation will facilitate interdisciplinary dialogue on key One Health priorities, including antimicrobial resistance, infectious and zoonotic diseases, veterinary and public health, environmental and planetary health, food and agricultural sustainability, Siddha and Indian Knowledge Systems (IKS), biotechnology, nanotechnology, innovation, public health and policy governance. It will provide an opportunity to identify emerging challenges, regional priorities and research needs relevant to Tamil Nadu and to develop scientifically relevant sessions, lectures, panel discussions and collaborative activities for GOHC 2026. The consultation will further encourage the exchange of expertise, experiences and innovative ideas among participating institutions and stakeholders, while strengthening academia–industry–healthcare–government partnerships and identifying opportunities for joint research, knowledge exchange, capacity building and translational initiatives. The inputs and recommendations emerging from the consultation will contribute towards shaping a comprehensive and impactful conference programme aligned with the theme \"Bridging Microbes, Molecules & Mankind for Sustainability\", while promoting integrated, evidence-based and sustainable approaches to human, animal and environmental health.','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(390,'pre_conf_schedule_note','Proposed date: 25th September 2026 | Venue: Blue-whale auditorium, MMIP | Mode: Hybrid','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(391,'pre_conf_panel','Panel discussion with Doctors and health care experts (Tentative)','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(397,'pre_conf_speaker_1_name','Prof. Dr. Raman Muthusamy','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(398,'pre_conf_speaker_1_image','images/raman_muthusamy_cropped.png','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(399,'pre_conf_speaker_1_affiliation','Advisor & Cluster Head, One Health, Center for Global Healrtth Research, Saveetha Medical College, Former Director, Translational Research platform for Veterinary Biologicals, TANUVAS, Chennai','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(400,'pre_conf_speaker_1_expertise','One Health, AMR, Zoonotic disease and translational research','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(401,'pre_conf_speaker_2_name','Dr. S. Suresh Kannan','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(402,'pre_conf_speaker_2_image','images/suresh_kannan.png','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(403,'pre_conf_speaker_2_affiliation','Professor & Head, Department of Veterinary Public Health and Epidemiology, Madras Veterinary college, Chennai','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(404,'pre_conf_speaker_2_expertise','One health, zoonotic disease surveillance, AMR and veterinary public health','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(405,'pre_conf_speaker_3_name','Dr. M. Meenakshi Sundaram','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(406,'pre_conf_speaker_3_image','images/meenakshi_sundaram.png','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(407,'pre_conf_speaker_3_affiliation','Dean, Professor & Head, Department of Kuzhandhai Muruthuvam, National Institute of Siddha, Chennai','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(408,'pre_conf_speaker_3_expertise','Indian Knowledge system','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(409,'pre_conf_speaker_4_name','Dr. V. Vijaykumar','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(410,'pre_conf_speaker_4_image','','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(411,'pre_conf_speaker_4_affiliation','Expert Advisor for child health, National Health Mission, Chennai','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(412,'pre_conf_speaker_4_expertise','Public health integration and environmental determinants and health policy','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(413,'pre_conf_speaker_5_name','Dr. Ramdev Krishnan. J','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(414,'pre_conf_speaker_5_image','images/ramdev_krishnan.png','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(415,'pre_conf_speaker_5_affiliation','Head of Operations, Mazumdarshaw Medical Foundation (MSMF)-TBI Narayana Health, Bangalore','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(416,'pre_conf_speaker_5_expertise','AI in health-care','text','pre_conference',NULL,'2026-09-25 06:41:07','2026-09-25 06:41:07'),(417,'track_1_name','Track I','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(418,'track_1_topic','Emerging infectious diseases through a One health lens (for medical practitioners)','text','schedule',NULL,'2026-09-29 06:20:57','2026-10-05 06:57:05'),(419,'track_1_adjudicator','Dr. Ananthi Rachel Livingstone, Head of the Dept.','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(420,'track_1_staff','Dr.S. Niren Andrew, Assistant Professor, Department of Microbiology,Madras Christian College, Chennai-59 & Mrs.Adline Jennefa Daniel, Assistant Professor, Department of Zoology, Madras Christian College, Chennai-59','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(421,'track_1_color','#009688','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(422,'track_2_name','Track II','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(423,'track_2_topic','Strengthening Health Systems from Theory to Practice: Embedding Social Infrastructure and Public Governance in One Health Capacities','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(424,'track_2_adjudicator','Dr. R. Sridhar, Vice-Principal (Admin), Associate Professor','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(425,'track_2_staff','Dr.S.Premina, Assistant Professor, Department of Microbiology,Madras Christian College, Chennai-59 & Dr.Milton Devadayavu N, Assistant Professor, Department of Public Administration, Madras Christian College, Chennai-59','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(426,'track_2_color','#3b82f6','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(427,'track_3_name','Track III','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(428,'track_3_topic','Integrating Environment and Climate Change in One Health','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(429,'track_3_adjudicator','Dr. E. Joyce Sudandara Priya, Head of the Dept.','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(430,'track_3_staff','Dr. P. Hanumantha Rao, Associate Professor, Department of Microbiology,Madras Christian College, Chennai-59 & Dr.U. Senthilkumar, Assistant Professor, Department of Botany, Madras Christian College, Chennai-59','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(431,'track_3_color','#8b5cf6','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(432,'track_4_name','Track IV','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(433,'track_4_topic','Translating Sustainable Chemistry and Future Technologies to One Health','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(434,'track_4_adjudicator','Dr. E. Iyyappan, Head of the Department','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(435,'track_4_staff','Dr.S.Abirami, Assistant Professor, Department of Microbiology,Madras Christian College, Chennai-59 & Dr. R. Vijay Solomon, Assistant Professor, Department of Chemistry (Aided), Madras Christian College, Chennai-59','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(436,'track_4_color','#ec4899','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(437,'track_5_name','Track V','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(438,'track_5_topic','Ensuring health intervention through the Indian Knowledge System','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(439,'track_5_adjudicator','Prof. Dr.S. Sivakkumar, Professor / Gunapadam','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(440,'track_5_staff','Dr.V.Vedha, Assistant Professor, Department of Microbiology,Madras Christian College, Chennai-59 & Dr. K. Vijayalakshmi, Assistant Professor, Department of Chemistry (SFS), Madras Christian College, Chennai-59','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(441,'track_5_color','#f59e0b','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(442,'track_6_name','Track VI','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(443,'track_6_topic','Regenerative Health: Redefining Industrial One Health Paradigms (for industry track)','text','schedule',NULL,'2026-09-29 06:20:57','2026-10-05 06:57:05'),(444,'track_6_adjudicator','Dr. T.Sathish Kumar, Associate Professor','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(445,'track_6_staff','Dr. T.Sathish Kumar, Associate Professor, Department of Microbiology,Madras Christian College, Chennai-59 & Dr.S. Daniel Abraham, Assistant Professor, Department of Chemistry (SFS), Madras Christian College, Chennai-59','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(446,'track_6_color','#10b981','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(447,'track_count','6','text','schedule',NULL,'2026-09-29 06:20:57','2026-09-29 06:20:57'),(448,'contact_whatsapp_link','https://wa.me/918148018894','text','general',NULL,NULL,NULL),(449,'awards_count','3','text','awards_page',NULL,'2026-10-05 04:13:21','2026-10-05 04:13:21'),(450,'page_contact-us','\n<div style=\"font-family: \'Inter\', sans-serif;\">\n    <div style=\"display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; margin-bottom: 35px;\">\n        <div style=\"background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 25px; display: flex; align-items: flex-start; gap: 18px;\">\n            <div style=\"width: 50px; height: 50px; border-radius: 10px; background: rgba(0, 168, 150, 0.1); color: #00A896; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; flex-shrink: 0;\">\n                <i class=\"fa-solid fa-globe\"></i>\n            </div>\n            <div>\n                <h4 style=\"margin: 0 0 6px 0; font-size: 1.1rem; color: #0a192f; font-weight: 700;\">Official Website</h4>\n                <a href=\"https://biomed.mccmrfip.in/\" target=\"_blank\" style=\"color: #00A896; font-weight: 600; text-decoration: none; font-size: 1rem; word-break: break-all;\">https://biomed.mccmrfip.in/</a>\n            </div>\n        </div>\n\n        <div style=\"background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 25px; display: flex; align-items: flex-start; gap: 18px;\">\n            <div style=\"width: 50px; height: 50px; border-radius: 10px; background: rgba(0, 168, 150, 0.1); color: #00A896; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; flex-shrink: 0;\">\n                <i class=\"fa-solid fa-envelope\"></i>\n            </div>\n            <div>\n                <h4 style=\"margin: 0 0 6px 0; font-size: 1.1rem; color: #0a192f; font-weight: 700;\">Official Email</h4>\n                <a href=\"mailto:gohc2026@gmail.com\" style=\"color: #00A896; font-weight: 600; text-decoration: none; font-size: 1rem;\">gohc2026@gmail.com</a>\n            </div>\n        </div>\n    </div>\n\n    <div style=\"background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.03);\">\n        <h3 style=\"font-size: 1.3rem; font-weight: 800; color: #0a192f; margin-top: 0; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;\">\n            <i class=\"fa-solid fa-address-book\" style=\"color: #00A896;\"></i> Contact Persons\n        </h3>\n\n        <div style=\"display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 18px;\">\n            <div style=\"background: #f8fafc; border-left: 4px solid #00A896; border-radius: 8px; padding: 18px 20px;\">\n                <span style=\"font-size: 0.82rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 4px;\">Organizing Secretary 1</span>\n                <a href=\"tel:7397539543\" style=\"font-size: 1.2rem; font-weight: 700; color: #0a192f; text-decoration: none; display: flex; align-items: center; gap: 8px;\">\n                    <i class=\"fa-solid fa-phone\" style=\"font-size: 0.95rem; color: #00A896;\"></i> +91 73975 39543\n                </a>\n            </div>\n\n            <div style=\"background: #f8fafc; border-left: 4px solid #00A896; border-radius: 8px; padding: 18px 20px;\">\n                <span style=\"font-size: 0.82rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 4px;\">Organizing Secretary 2</span>\n                <a href=\"tel:8148018894\" style=\"font-size: 1.2rem; font-weight: 700; color: #0a192f; text-decoration: none; display: flex; align-items: center; gap: 8px;\">\n                    <i class=\"fa-solid fa-phone\" style=\"font-size: 0.95rem; color: #00A896;\"></i> +91 81480 18894\n                </a>\n            </div>\n\n            <div style=\"background: #f8fafc; border-left: 4px solid #00A896; border-radius: 8px; padding: 18px 20px;\">\n                <span style=\"font-size: 0.82rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 4px;\">Student Chairman</span>\n                <a href=\"tel:9025596984\" style=\"font-size: 1.2rem; font-weight: 700; color: #0a192f; text-decoration: none; display: flex; align-items: center; gap: 8px;\">\n                    <i class=\"fa-solid fa-phone\" style=\"font-size: 0.95rem; color: #00A896;\"></i> +91 90255 96984\n                </a>\n            </div>\n\n            <div style=\"background: #f8fafc; border-left: 4px solid #00A896; border-radius: 8px; padding: 18px 20px;\">\n                <span style=\"font-size: 0.82rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 4px;\">Student Coordinator</span>\n                <a href=\"tel:9789582404\" style=\"font-size: 1.2rem; font-weight: 700; color: #0a192f; text-decoration: none; display: flex; align-items: center; gap: 8px;\">\n                    <i class=\"fa-solid fa-phone\" style=\"font-size: 0.95rem; color: #00A896;\"></i> +91 97895 82404\n                </a>\n            </div>\n        </div>\n    </div>\n</div>\n','text','custom_pages',NULL,'2026-10-05 06:29:23','2026-10-05 06:29:23'),(451,'footer_website','https://biomed.mccmrfip.in/','text','general',NULL,'2026-10-05 06:29:23','2026-10-05 06:29:23'),(452,'nav_home_label','Home','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(453,'nav_home_url','/','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(454,'nav_home_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(455,'nav_tech_events_label','Technical Events','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(456,'nav_tech_events_url','#','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(457,'nav_tech_events_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(458,'nav_tracks_label','Tracks','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(459,'nav_tracks_url','/scientific-themes','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(460,'nav_tracks_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(461,'nav_event_list_label','Event List','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(462,'nav_event_list_url','#','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(463,'nav_event_list_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(464,'nav_oral_label','Oral Presentation','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(465,'nav_oral_url','/page/oral-presentation','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(466,'nav_oral_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(467,'nav_poster_label','Poster Presentation','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(468,'nav_poster_url','/page/poster-presentation','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(469,'nav_poster_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(470,'nav_innovation_label','Innovation Pitch','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(471,'nav_innovation_url','/page/innovation-pitch','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(472,'nav_innovation_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(473,'nav_hackathon_label','Hackathon','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(474,'nav_hackathon_url','/page/hackathon','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(475,'nav_hackathon_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(476,'nav_publications_label','Publications','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(477,'nav_publications_url','/publications','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(478,'nav_publications_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(479,'nav_registrations_label','Registrations','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(480,'nav_registrations_url','/registration','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(481,'nav_registrations_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(482,'nav_experts_label','Speakers','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(483,'nav_experts_url','#','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(484,'nav_experts_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(485,'nav_keynote_label','Keynote Speakers','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(486,'nav_keynote_url','/keynote-speakers','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(487,'nav_keynote_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(488,'nav_distinguished_label','Distinguished Speakers','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(489,'nav_distinguished_url','/distinguished-speakers','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(490,'nav_distinguished_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(491,'nav_dist_awards_label','Distinguished Awards','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(492,'nav_dist_awards_url','/awards','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(493,'nav_dist_awards_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(494,'nav_committee_label','Committee','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(495,'nav_committee_url','/committee','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(496,'nav_committee_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(497,'nav_preconf_label','Pre-Conference','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(498,'nav_preconf_url','/pre-conference','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(499,'nav_preconf_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(500,'nav_stall_label','Stall Booking and Merchandise','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(501,'nav_stall_url','/page/stall-booking-and-merchandise','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(502,'nav_stall_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(503,'nav_mcc_label','Glimpse of MCC','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(504,'nav_mcc_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(505,'nav_mcc_gallery_label','MCC Gallery','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(506,'nav_visit_places_label','Places to Visit','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(507,'nav_contact_label','Contact Us','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(508,'nav_contact_url','/page/contact-us','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(509,'nav_contact_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(510,'nav_register_label','REGISTER','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(511,'nav_register_url','/registration','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(512,'nav_register_show','1','text','navigation',NULL,'2026-10-06 06:22:32','2026-10-06 06:22:32'),(513,'pub_note','Journal list will be updated soon','text','highlights',NULL,'2026-10-06 06:41:28','2026-10-06 06:41:28'),(514,'footer_logo','images/77.png','image','footer','Footer Logo Image','2026-10-07 01:45:02','2026-10-07 01:45:02'),(515,'contact_phone_2','+91 9025596984','text','contact','Contact Phone 2','2026-10-07 01:50:26','2026-10-07 01:50:26'),(516,'contact_phone_3','+91 81480 18894','text','contact','Contact Phone 3','2026-10-07 01:50:26','2026-10-07 01:50:26'),(517,'oral_banner_title','ORAL PRESENTATION','text','oral_presentation',NULL,'2026-10-07 03:37:18','2026-10-07 03:37:18'),(518,'oral_section_title','Abstract Submission & Oral Presentation Guidelines','text','oral_presentation',NULL,'2026-10-07 03:37:18','2026-10-07 03:37:18'),(519,'oral_announcement','We are delighted to announce abstract submissions from scientists, academicians, healthcare professionals, research scholars, and students working across the One Health domains. Selected abstracts will be allotted slots for live oral presentations during dedicated technical track sessions.','text','oral_presentation',NULL,'2026-10-07 03:37:18','2026-10-07 03:37:18'),(520,'oral_spec_duration','8 mins presentation + 2 mins Q&A','text','oral_presentation',NULL,'2026-10-07 03:37:18','2026-10-07 03:37:18'),(521,'oral_spec_format','16:9 Widescreen (PPTX / PDF)','text','oral_presentation',NULL,'2026-10-07 03:37:18','2026-10-07 03:37:18'),(522,'oral_spec_lang','English (Official Conference Medium)','text','oral_presentation',NULL,'2026-10-07 03:37:18','2026-10-07 03:37:18'),(523,'oral_guidelines_json','[\"Applicable Tracks: Dedicated guidelines for Track 1 (Medical Practitioners) and Track 6 (Industry)\",\"Submit the abstract in MS-Word format. The abstract should be 250\\u2013300 words in length.\",\"Abstracts will be considered only after receipt of registration fee.\",\"Presenting author is to be marked with # and corresponding author with *\",\"Include 5 to 6 keywords at the end of the abstract.\",\"Upload the Abstract using the designated Google Form submission portal.\",\"Provide the email ID of the corresponding author.\"]','text','oral_presentation',NULL,'2026-10-07 03:37:18','2026-10-07 03:40:05'),(524,'pre_conf_hero_title','PRE-CONFERENCE WORKSHOP','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(525,'pre_conf_hero_sub1','Pre-Conference Consultative Workshop on 9th October 2026','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(526,'pre_conf_hero_sub2','GLOBAL ONE HEALTH CONFLUENCE 2026','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(527,'pre_conf_hero_sub3','Bridging Microbes, Molecules & Mankind for Sustainability','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(528,'pre_conf_preamble_title','PREAMBLE','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(529,'pre_conf_preamble_icon','fa-solid fa-book-open','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(532,'pre_conf_obj_1','To obtain expert inputs for the scientific and thematic planning of Global One Health Confluence 2026.','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(533,'pre_conf_obj_2','To facilitate interdisciplinary dialogue on human health, animal health, environmental health and allied One Health domains.','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(534,'pre_conf_obj_3','To discuss regional priorities related to antimicrobial resistance, infectious diseases, zoonotic diseases, veterinary public health, IKS and public health.','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(535,'pre_conf_obj_4','To integrate diverse expert perspectives into the scientific sessions and thematic discussions of GOHC 2026.','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(536,'pre_conf_obj_5','To strengthen institutional and professional collaboration towards advancing sustainable and integrated One Health approaches.','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(537,'pre_conf_obj_count','5','text','pre_conference',NULL,'2026-10-07 04:04:46','2026-10-07 04:04:46'),(538,'contact_foreign_title','Foreign Students','text','contact',NULL,'2026-10-07 04:43:17','2026-10-07 04:43:17'),(539,'contact_foreign_note','Kindly contact Dean IP regarding Visa','text','contact',NULL,'2026-10-07 04:43:17','2026-10-07 04:43:17'),(540,'contact_foreign_email','deanip@mcc.edu.in','text','contact',NULL,'2026-10-07 04:43:17','2026-10-07 04:43:17'),(541,'contact_accom_title','Accommodation','text','contact',NULL,'2026-10-07 04:43:17','2026-10-07 04:43:17'),(542,'contact_accom_note','Will be updated soon','text','contact',NULL,'2026-10-07 04:43:17','2026-10-07 04:43:17'),(543,'contact_hero_title','CONTACT US','text','contact',NULL,'2026-10-07 04:43:17','2026-10-07 04:43:17'),(544,'contact_page_title','Contact Us','text','contact',NULL,'2026-10-07 04:43:17','2026-10-07 04:43:17'),(545,'contact_website','https://biomed.mccmrfip.in/','text','contact',NULL,'2026-10-07 04:43:17','2026-10-07 04:43:17'),(546,'topbar_ticker_mode','custom','text','topbar',NULL,'2026-10-07 04:51:23','2026-10-07 04:51:23'),(547,'topbar_ticker_1','All the Presentation will be published as a conference proceedings in ISBN indexed book','text','topbar',NULL,'2026-10-07 04:51:23','2026-10-07 04:51:23'),(548,'topbar_ticker_2','Quality presentation will be peer reviewed and considered for further publication in selected Scopus/ WoS indexed journals','text','topbar',NULL,'2026-10-07 04:51:23','2026-10-07 04:51:23'),(549,'stall_banner_title','STALL BOOKING AND MERCHANDISE','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 05:39:24'),(550,'stall_banner_subtitle','Partnership Avenues, Tariff Details & Sponsorship Opportunities | Global One Health Confluence 2026','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 05:39:24'),(551,'stall_brochures_json','[{\"title\":\"Partnership Avenues for Analytical Service Providers\",\"image\":\"images\\/stall_booking\\/stall_brochure_1.png\"},{\"title\":\"Tariff Details & Sponsorship Opportunities (Matrix)\",\"image\":\"images\\/stall_booking\\/stall_brochure_2.png\"},{\"title\":\"Partnership Avenues for Hospitals & Health Sectors\",\"image\":\"images\\/stall_booking\\/stall_brochure_3.png\"},{\"title\":\"Tariff Details & Sponsorship Opportunities (Contact & Notes)\",\"image\":\"images\\/stall_booking\\/stall_brochure_4.png\"}]','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 06:42:39'),(552,'stall_sponsors_badge','Proudly Supported By','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 05:39:24'),(553,'stall_sponsors_title','Our Sponsors & Industry Partners','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 05:39:24'),(554,'stall_sponsors_json','[{\"name\":\"Anderson Diagnostics & Labs\",\"logo\":\"images\\/sponsors\\/anderson_logo.svg\",\"link\":\"https:\\/\\/andersondiagnostics.com\"},{\"name\":\"Sponsorship Partner\",\"logo\":\"images\\/sponsors\\/sponsor_logo_1.jpg\",\"link\":\"#\"}]','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 05:39:24'),(555,'stall_cta_text','Interested in partnering or booking an exhibition stall?','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 05:39:24'),(556,'stall_cta_btn_label','Contact Sponsorship Committee','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 05:39:24'),(557,'stall_cta_btn_url','/contact','text','stall_booking',NULL,'2026-10-07 05:39:24','2026-10-07 05:39:24'),(558,'tracks_banner_title','SCIENTIFIC TRACKS & THRUST AREAS','text','tracks_page',NULL,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(559,'tracks_banner_subtitle','Research and innovation at the confluence of human, animal, and environmental health. Discover the multidisciplinary tracks and focus areas shaping this conference.','text','tracks_page',NULL,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(560,'tracks_section_badge','Conference Themes','text','tracks_page',NULL,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(561,'tracks_section_title','Thrust Areas','text','tracks_page',NULL,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(562,'tracks_section_desc','Explore the core conference tracks, thrust topics, and focus areas driving our collaborative approach to global One Health.','text','tracks_page',NULL,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(563,'tracks_references_title','References','text','tracks_page',NULL,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(564,'tracks_references_json','[\"Qasim, S., Khan, A. U., & Raza, A. (2024). Zoonotic diseases and antimicrobial resistance: a dual threat at the human\\u2013animal interface.\",\"Bett, B., F\\u00e8vre, E. M., Ha Thi Thanh Nguyen, Sinh Dang-Xuan, Obuta, A., Mateo-Sagasta, J., & Patel, E. (2024). Enhancing public health: Five key takeaways on zoonotic disease and antimicrobial resistance surveillance. One Health Knowledge Brief. Nairobi, Kenya: ILRI.\",\"Constructing a One Health governance architecture: a systematic review and analysis of governance mechanisms for One Health. (2024). PMC11631453.\",\"Analyzing One Health governance and implementation challenges. (2025). BMJ Open, 16(7), e115471.\",\"Zielinski, C., et al. (2023). Time to treat the climate and nature crisis as one indivisible global health emergency. BMC Global and Public Health, 1:29.\",\"One Health: Change our Paradigm, Change our Lives. (2023). Universidade de \\u00c9vora.\",\"Editorial: Advances in nanotechnology for the removal and detection of emerging contaminants from water. (2025). Frontiers in Chemistry.\",\"Call for papers: Next-generation green remediation technologies for emerging contaminants. (2025). Bentham Science.\",\"Traditional medicine and intellectual property rights among Indian Indigenous communities: a review. (2023). University of Lapland research repository.\",\"Indian Journal of Traditional Knowledge. National Institute of Science Communication and Policy Research (CSIR).\",\"ESG in pharma: How CDMOs drive sustainable supply chains. (2025). Neuland Labs.\",\"Sustainability in Pharma Industry [white paper]. (2025). Indian Pharmaceutical Alliance.\"]','text','tracks_page',NULL,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(565,'topbar_speed','55','text','topbar',NULL,'2026-10-07 06:45:52','2026-10-07 06:45:52');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `speakers`
--

DROP TABLE IF EXISTS `speakers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `speakers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'plenary',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h_index` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `biography` text COLLATE utf8mb4_unicode_ci,
  `field` text COLLATE utf8mb4_unicode_ci,
  `current_role` text COLLATE utf8mb4_unicode_ci,
  `education` text COLLATE utf8mb4_unicode_ci,
  `honours` text COLLATE utf8mb4_unicode_ci,
  `key_achievements` text COLLATE utf8mb4_unicode_ci,
  `relevance` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `speakers`
--

LOCK TABLES `speakers` WRITE;
/*!40000 ALTER TABLE `speakers` DISABLE KEYS */;
INSERT INTO `speakers` VALUES (8,'distinguished','Prof. Ts. Dr. Liew Kai Bin',NULL,'University of Cyberjaya (UoC)','Malaysia','Head, Department of Pharmaceutical Technology & Industry','images/speakers/liew_kai_bin.png',4,'2026-08-19 05:04:27','2026-08-19 05:04:27','Prof. Ts. Dr. Liew Kai Bin is Head of the Department of Pharmaceutical Technology & Industry at the Faculty of Pharmacy, University of Cyberjaya (UoC), Malaysia. He holds a BPharm (Hons) and an MSc in Pharmaceutical Technology from Universiti Sains Malaysia (USM), together with a PhD, and is a registered Technologist (Ts.) recognised for bridging formulation science with real-world pharmaceutical innovation.\n\nHis research centres on advanced oral pharmaceutics and next-generation drug delivery systems, spanning nanoparticles and micelles, liposomal formulations for skin repair, fucoidan-based nanoparticles for anti-ageing cosmeceutics, and probiotic orodispersible films for oral health. His work also covers bioequivalence studies, anti-cancer compound discovery (including the natural flavonoid luteolin), and biopharmaceutics — consistently aimed at moving formulations from the laboratory bench toward commercialisation and patient impact.','Pharmaceutical Technology — Advanced Oral Pharmaceutics, Nanoformulations & Cosmeceutics','Professor and Head, Department of Pharmaceutical Technology & Industry, Faculty of Pharmacy, University of Cyberjaya','BPharm (Hons), Universiti Sains Malaysia (USM); MSc (Pharmaceutical Technology), USM; PhD','1,500+ citations on Google Scholar; FRGS Grant Awardee (RM144,300); Registered Technologist (Ts.)','• Head of the Department of Pharmaceutical Technology & Industry, Faculty of Pharmacy, University of Cyberjaya.\n• Secured a Fundamental Research Grant Scheme (FRGS) award of RM144,300 from Malaysia\'s Ministry of Higher Education for research on the anticancer properties of luteolin.\n• Cited author (1,500+ citations on Google Scholar) with an active publication record in pharmaceutical technology, spanning nanoformulations, bioequivalence, and cosmeceutical drug delivery.\n• Recognised nationally as a Youth awardee for research contributions, alongside multiple national and international team research awards at UoC.\n• Active mentor of undergraduate and graduate students, embedding them as co-authors and conference presenters in ongoing translational research projects.\n• Research aligned with UN Sustainable Development Goals 3 (Good Health & Well-being) and 17 (Partnerships for the Goals), with active industry and international collaborations across Japan, India, and Indonesia.','Prof. Liew offers strong, practice-oriented expertise in pharmaceutical technology, nanoformulation, and cosmeceutical innovation, with a clear translational and commercialisation focus. He is well suited to keynote engagements on drug delivery systems, nanotechnology in pharmaceutics, and research mentorship for pharmacy and biomedical science audiences, and speaks readily to the practical challenges of moving research from lab to market.'),(10,'distinguished','Professor Mohan K. Balasubramanian','47','Warwick Medical School, University of Warwick','United Kingdom','Wellcome Trust Senior Investigator | Pro-Dean (Biomedical Research)','images/speakers/cropped_mohan.png',1,'2026-08-19 05:04:28','2026-08-19 05:04:28','Professor Mohan Balasubramanian studies the molecular mechanisms driving cytokinesis — the process by which a single cell physically divides into two. His laboratory combines yeast genetics, high-resolution imaging, and biochemistry, primarily using the fission yeasts Schizosaccharomyces pombe and S. japonicus as model systems to dissect how the actomyosin contractile ring assembles and constricts during cell division.\n\nHe graduated in chemistry from Madras University, India, and pursued postgraduate studies in microbiology and biotechnology in Baroda, India, before completing his doctoral research at the University of Saskatchewan, Canada, where he began his study of fission-yeast cell division. Following postdoctoral work at Vanderbilt University, USA, he joined the Institute of Molecular Agrobiology in Singapore in 1997, moved to the Temasek Life Sciences Laboratory in Singapore in 2002, and relocated to the University of Warwick, UK, in 2014.','Cell Biology — Molecular Mechanisms of Cytokinesis','Wellcome Trust Senior Investigator and Pro-Dean (Biomedical Research), Warwick Medical School, University of Warwick','B.Sc. Chemistry, Madras University; postgraduate studies in Microbiology & Biotechnology, Baroda, India; PhD, University of Saskatchewan, Canada; Postdoctoral research, Vanderbilt University, USA','Wolfson Merit Award Holder; h-index of 47 with 146+ publications','• Wellcome Trust Senior Investigator and Wolfson Merit Award holder, recognising sustained, high-impact contributions to cell biology.\n• Author of over 140 peer-reviewed publications on cytokinesis, with more than 1,500 citations and an h-index of 47.\n• Identified and characterised several core cytokinesis genes (including tropomyosin, myosin light chain, and profilin components) foundational to the field.\n• Serves as Pro-Dean (Biomedical Research) at Warwick Medical School, shaping the university\'s biomedical research strategy.\n• Long-standing collaborative research network spanning the UK, USA, Singapore, and India.','Professor Balasubramanian offers deep expertise in fundamental cell biology and the genetics of cell division, of direct relevance to microbiology, cell and molecular biology audiences. His career path — from Tamil Nadu to leading international laboratories — also makes for a compelling narrative on scientific mentorship and global research careers.'),(11,'distinguished','Dr. Priya Abraham',NULL,'Christian Medical College (CMC), Vellore','India','Senior Professor, Department of Clinical Virology, CMC Vellore | Former Director, ICMR–NIV','images/speakers/priya_abraham.png',2,'2026-08-19 05:04:28','2026-08-19 05:06:06','Dr. Priya Abraham is an Indian virologist and physician recognised for her leadership in viral diagnostics and research, most notably as Director of the ICMR-National Institute of Virology (NIV), Pune, from November 2019 to early 2024. She took charge of NIV barely two months before the first COVID-19 case was detected in India, and her institute went on to isolate the SARS-CoV-2 virus and lead the country\'s genomic surveillance and testing response.\n\nOriginally from Kottayam, Kerala, she earned her MD and PhD in biology from Christian Medical College (CMC), Vellore, in 1981, where she subsequently headed the Clinical Virology section, focusing initially on hepatitis and human papillomaviruses. Under her leadership, NIV reduced COVID-19 sample testing time from 12–14 hours to just four, while scaling testing capacity, distributing kits nationally, and monitoring emerging variants.','Clinical Virology & Viral Diagnostics','Former Director, ICMR-National Institute of Virology (NIV), Pune; Senior Professor, CMC Vellore','MD and PhD in Biology, Christian Medical College (CMC), Vellore (1981)','Fellow, Indian National Science Academy (2023); Advisor to WHO and ICMR Scientific Advisory Committee','• Led NIV\'s isolation of the first SARS-CoV-2 sample in India (March 2020) and the country\'s genomic surveillance response.\n• Elected Fellow of the Indian National Science Academy (September 2023).\n• Advised the World Health Organization on viral infections and served on the ICMR Scientific Advisory Committee.\n• Oversaw development of indigenous COVID-19 testing assays and supported vaccine and convalescent-plasma trials nationally.\n• Decades of prior leadership in clinical virology at CMC Vellore, mentoring generations of virologists and researchers.','Dr. Abraham brings first-hand experience leading a national institution through a global pandemic, making her an outstanding speaker on public health preparedness, viral diagnostics, crisis leadership in science, and the translation of laboratory research into national policy response — highly relevant to microbiology and public health audiences.'),(13,'keynote','Dr. Soumya Swaminathan',NULL,'MSSRF','India','Chairperson, M. S. Swaminathan Research Foundation (MSSRF)','images/soumya_swaminathan.jpg',1,'2026-09-15 06:39:01','2026-09-15 06:39:01','Dr. Soumya Swaminathan is a globally renowned pediatrician, clinical scientist, and public health leader. She served as the inaugural Chief Scientist at the World Health Organization (WHO) from 2019 to 2022, and previously as WHO\'s Deputy Director-General for Programmes.\n\nShe is currently the Chairperson of the M. S. Swaminathan Research Foundation (MSSRF) in Chennai, India. Prior to joining WHO, Dr. Swaminathan served as the Director-General of the Indian Council of Medical Research (ICMR) and Secretary of the Department of Health Research, Government of India. She is a Fellow of the Royal Society (FRS) and has made groundbreaking contributions to tuberculosis and HIV research.','Fellow of the Royal Society | Global Public Health & Clinical Research','Former Chief Scientist and Deputy Director-General for Programmes, World Health Organization (WHO)','MBBS, AFMC Pune; MD in Pediatrics, AIIMS New Delhi; Diplomate of National Board; Postdoctoral Fellowship in Pediatric Pulmonology, Children\'s Hospital Los Angeles, USC.','Fellow of the Royal Society (FRS); Fellow of the National Academy of Sciences, India (NASI); Fellow of the Indian National Science Academy (INSA).','• Inaugural Chief Scientist of the World Health Organization (WHO) (2019–2022).\n• Former Deputy Director-General for Programmes, WHO.\n• Former Director-General of the Indian Council of Medical Research (ICMR).\n• Fellow of the Royal Society (FRS).','As former WHO Chief Scientist and a world-renowned leader in medical research, Dr. Swaminathan offers invaluable insights on global pandemic preparedness, public health policy, research translation, and planetary One Health governance.'),(14,'keynote','Padma Shri Prof. K. VijayRaghavan',NULL,'NCBS, TIFR','India','Former Principal Scientific Adviser to the Government of India','images/vijayraghavan.jpg',2,'2026-09-15 06:42:31','2026-09-15 06:42:31','Padma Shri Prof. K. VijayRaghavan is a distinguished developmental biologist and former Principal Scientific Adviser to the Government of India (2018–2022). He is an Emeritus Professor and former Director of the National Centre for Biological Sciences (NCBS), Tata Institute of Fundamental Research (TIFR), Bengaluru.\n\nHis research addresses the fundamental principles and mechanisms that govern the nervous system and muscles during development. He trained as a chemical engineer at IIT Kanpur before completing his doctoral work at TIFR and postdoctoral research at Caltech. He also served as Secretary of India\'s Department of Biotechnology (DBT).','Developmental Biology, Genetics & Neurogenetics','Emeritus Professor, National Centre for Biological Sciences (NCBS), Tata Institute of Fundamental Research (TIFR), Bengaluru, India','B.Tech (1975) & M.Tech (1977) in Chemical Engineering, IIT Kanpur; PhD in Molecular Biology (1983), TIFR; Postdoctoral research, Caltech (1984–88).','Padma Shri (2013); Fellow of the Royal Society (FRS, 2012); Foreign Associate, US National Academy of Sciences (2014); Shanti Swarup Bhatnagar Prize (1998).','• Former Principal Scientific Adviser to the Government of India.\n• Recipient of Padma Shri (2013), one of India\'s highest civilian honors.\n• Fellow of the Royal Society (FRS, 2012).\n• Shanti Swarup Bhatnagar Prize recipient (1998).','As a former national science policy chief and leading developmental biologist, Prof. VijayRaghavan brings profound insight into science governance, neurogenetics, biotechnology capability, and multi-sectoral One Health research.'),(15,'distinguished','Dr. G. S. Murthy',NULL,'IIT Indore','India','Professor & Head, Centre for Scientific Indian Knowledge Systems','images/gs_murthy.jpg',3,'2026-09-15 06:48:35','2026-09-15 06:48:35','Dr. G. S. Murthy is a Professor and Head of the Centre for Scientific Indian Knowledge Systems at the Indian Institute of Technology (IIT) Indore. His work focuses on scientific validation, preservation, and modern technological integration of traditional Indian knowledge systems, biosystems engineering, and sustainable technologies.','Scientific Indian Knowledge Systems & Interdisciplinary Engineering','Professor & Head, Centre for Scientific Indian Knowledge Systems, Indian Institute of Technology Indore, India','PhD in Biological & Agricultural Engineering; M.Tech & B.Tech in Agricultural & Food Engineering.','Head of Centre for Scientific Indian Knowledge Systems, IIT Indore; Renowned academician in IKS and sustainable engineering.','• Head of the Centre for Scientific Indian Knowledge Systems, IIT Indore.\n• Leading groundbreaking research on scientific validation and modern integration of traditional Indian knowledge.\n• Published extensively in international peer-reviewed journals.','Dr. Murthy brings authoritative expertise on Indian Knowledge Systems (IKS), traditional health practices, and modern scientific synthesis.'),(16,'distinguished','Dr. G. Ravikanth',NULL,'ATREE, Bengaluru','India','Senior Fellow & Convenor, Academy for Conservation Science and Sustainability Studies','images/ravikanth.jpg',5,'2026-09-15 06:51:11','2026-09-15 06:51:11','Dr. G. Ravikanth is a Senior Fellow and Convenor at the Academy for Conservation Science and Sustainability Studies, Ashoka Trust for Research in Ecology and the Environment (ATREE), Bengaluru. His research focuses on plant population genetics, conservation of threatened flora, DNA barcoding, and sustainable resource management.','Conservation Genetics, Biodiversity & Ecosystem Sustainability','Senior Fellow & Convenor, Academy for Conservation Science and Sustainability Studies, ATREE, Bengaluru, India','PhD in Plant Genetics / Botany; MSc & BSc in Biological Sciences.','Senior Fellow & Convenor, ATREE; Leading expert in South Asian forest genetic resources and biodiversity conservation.','• Senior Fellow & Convenor, Academy for Conservation Science and Sustainability Studies, ATREE.\n• Leading extensive research on Western Ghats biodiversity, DNA barcoding, and endangered plant conservation.\n• Author of numerous high-impact publications in international conservation and genetics journals.','Dr. Ravikanth provides crucial expertise on ecosystem resilience, biodiversity conservation, and planetary health.'),(19,'plenary','Shahnaz Mansouri',NULL,'Monash University','Australia','Emerging Food Cultivation and Printing Technologies for Food Security and Personalization','images/speakers/speaker3.png',3,'2026-10-05 01:01:11','2026-10-05 01:01:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'plenary','Jingwei Xie','68','University of Nebraska Medical Center','United States','Emerging Nanofiber Materials for Biomedical Applications','images/speakers/speaker4.png',4,'2026-10-05 01:01:11','2026-10-05 01:01:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'distinguished','Dr. Upendra Bhojani',NULL,'Lead, Centre for Commercial Determinants of Health, India Alliance (DBT/Wellcome Trust) Senior Fellow, Former Director, Institute of Public Health','Bengaluru, India','Senior Fellow (Professor Grade)','images/speakers/1791357768.png',5,'2026-10-05 01:01:11','2026-10-07 01:52:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,'invited','Richard Spontak','68','North Carolina State University','United States','TBA','images/speakers/speaker6.png',6,'2026-10-05 01:01:11','2026-10-05 01:01:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'pre_conference','Prof. Dr. Raman Muthusamy',NULL,'Advisor & Cluster Head, One Health, Center for Global Health Research, Saveetha Medical College,\nFormer Director, Translational Research platform for Veterinary Biologicals, TANUVAS, Chennai','India',NULL,'images/speakers/raman_muthusamy.png',1,'2026-10-07 04:17:22','2026-10-07 04:17:22',NULL,'One Health, AMR, Zoonotic disease and translational research',NULL,NULL,NULL,NULL,NULL),(27,'pre_conference','Dr. S. Suresh Kannan',NULL,'Professor & Head, Department of Veterinary Public Health and Epidemiology, Madras Veterinary college, Chennai','India',NULL,'images/speakers/suresh_kannan.png',2,'2026-10-07 04:17:22','2026-10-07 04:17:22',NULL,'One health, zoonotic disease surveillance, AMR and veterinary public health',NULL,NULL,NULL,NULL,NULL),(28,'pre_conference','Dr. M. Meenakshi Sundaram',NULL,'Dean, Professor & Head, Department of Kuzhandhai Maruthuvam, National Institute of Siddha, Chennai','India',NULL,'images/speakers/meenakshi_sundaram.png',3,'2026-10-07 04:17:22','2026-10-07 04:17:22',NULL,'Indian Knowledge system',NULL,NULL,NULL,NULL,NULL),(29,'pre_conference','Dr. V. Vijaykumar',NULL,'Expert Advisor for child health, National Health Mission, Chennai','India',NULL,'images/speakers/1791371519.png',4,'2026-10-07 04:17:22','2026-10-07 05:41:59',NULL,'Public health integration and environmental determinants and health policy',NULL,NULL,NULL,NULL,NULL),(30,'pre_conference','Dr. Ramdev Krishnan. J',NULL,'Head of Operations, Mazumdarshaw Medical Foundation (MSMF)-TBI Narayana Health, Bangalore','India',NULL,'images/speakers/ramdev_krishnan.png',5,'2026-10-07 04:17:22','2026-10-07 04:17:22',NULL,'AI in health-care',NULL,NULL,NULL,NULL,NULL),(31,'pre_conference','Panel discussion with Doctors and health care experts (Tentative)',NULL,'-','India',NULL,NULL,6,'2026-10-07 04:17:22','2026-10-07 04:17:22',NULL,'-',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `speakers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sponsor_packages`
--

DROP TABLE IF EXISTS `sponsor_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sponsor_packages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `features` json DEFAULT NULL,
  `ribbon_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'tier',
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sponsor_packages`
--

LOCK TABLES `sponsor_packages` WRITE;
/*!40000 ALTER TABLE `sponsor_packages` DISABLE KEYS */;
INSERT INTO `sponsor_packages` VALUES (1,'PLATINUM','$8,500','[\"Premier logo placement on all conference materials\", \"5 complimentary full conference registrations\", \"Keynote speaking opportunity\", \"Exhibit booth in prime location\"]','bg-platinum','tier',1,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(2,'GOLD','$7,500','[\"Logo placement on all conference materials\", \"3 complimentary full conference registrations\", \"Speaking opportunity in a session\", \"Exhibit booth\"]','bg-gold','tier',2,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(3,'SILVER','$6,500','[\"Logo placement on all conference materials\", \"2 complimentary full conference registrations\", \"Exhibit booth\", \"Quarterpage ad in conference program\", \"Logo on conference website with link to sponsor\'s site\", \"Social media shoutouts\"]','bg-silver','tier',3,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(4,'BRONZE','$5,000','[\"Logo placement on all conference materials\", \"1 complimentary full conference registration\", \"Exhibit booth\", \"Logo on conference website with link to sponsor\'s site\", \"Social media shoutouts\"]','bg-bronze','tier',4,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(5,'Conference bag sponsorship','$2,500',NULL,NULL,'additional',1,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(6,'Lanyard sponsorship','$1,000',NULL,NULL,'additional',2,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(7,'Coffee break sponsorship','$1,500',NULL,NULL,'additional',3,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(8,'Networking reception sponsorship','$2,000',NULL,NULL,'additional',4,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(9,'PLATINUM','$8,500','[\"Premier logo placement on all conference materials\", \"5 complimentary full conference registrations\", \"Keynote speaking opportunity\", \"Exhibit booth in prime location\"]','bg-platinum','tier',1,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(10,'GOLD','$7,500','[\"Logo placement on all conference materials\", \"3 complimentary full conference registrations\", \"Speaking opportunity in a session\", \"Exhibit booth\"]','bg-gold','tier',2,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(11,'SILVER','$6,500','[\"Logo placement on all conference materials\", \"2 complimentary full conference registrations\", \"Exhibit booth\", \"Quarterpage ad in conference program\", \"Logo on conference website with link to sponsor\'s site\", \"Social media shoutouts\"]','bg-silver','tier',3,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(12,'BRONZE','$5,000','[\"Logo placement on all conference materials\", \"1 complimentary full conference registration\", \"Exhibit booth\", \"Logo on conference website with link to sponsor\'s site\", \"Social media shoutouts\"]','bg-bronze','tier',4,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(13,'Conference bag sponsorship','$2,500',NULL,NULL,'additional',1,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(14,'Lanyard sponsorship','$1,000',NULL,NULL,'additional',2,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(15,'Coffee break sponsorship','$1,500',NULL,NULL,'additional',3,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(16,'Networking reception sponsorship','$2,000',NULL,NULL,'additional',4,1,'2026-10-05 01:01:11','2026-10-05 01:01:11');
/*!40000 ALTER TABLE `sponsor_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submit_paper_fields`
--

DROP TABLE IF EXISTS `submit_paper_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submit_paper_fields` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `placeholder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  `options` json DEFAULT NULL,
  `grid_column` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'span 12',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `submit_paper_fields_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submit_paper_fields`
--

LOCK TABLES `submit_paper_fields` WRITE;
/*!40000 ALTER TABLE `submit_paper_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `submit_paper_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_number` int NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
INSERT INTO `topics` VALUES (1,'Biomedical Imaging',1,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(2,'AI and Robotics in Healthcare',1,2,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(3,'Telemedicine and Remote Health Monitoring',1,3,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(4,'Synthetic Biology and Bioengineering',1,4,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(5,'Nanomedicine and Nanobiotechnology',1,5,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(6,'Clinical Trials and Therapeutic Innovations',1,6,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(7,'Biomedical Signal Processing',2,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(8,'Biomedical Data Mining and Machine Learning',2,2,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(9,'Wearable Robotics and Exoskeletons',2,3,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(10,'Cellular Bioengineering',2,4,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(11,'Drug Discovery & Delivery',2,5,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(12,'Epigenetics and Gene Editing Technologies',2,6,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(13,'Advanced Medical Imaging Modalities',2,7,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(14,'Biomedical Engineering',3,1,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(15,'Biomedical Imaging and Signal Processing',3,2,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(16,'Medical Robotics and Automation',3,3,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(17,'Tissue Engineering',3,4,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(18,'Biofabrication and 3D Bioprinting Technologies',3,5,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(19,'Pharmaceutical Engineering',3,6,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(20,'Point-of-Care Diagnostic Technologies',3,7,'2026-08-19 04:16:38','2026-08-19 04:16:38'),(21,'Biomedical Imaging',1,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(22,'AI and Robotics in Healthcare',1,2,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(23,'Telemedicine and Remote Health Monitoring',1,3,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(24,'Synthetic Biology and Bioengineering',1,4,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(25,'Nanomedicine and Nanobiotechnology',1,5,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(26,'Clinical Trials and Therapeutic Innovations',1,6,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(27,'Biomedical Signal Processing',2,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(28,'Biomedical Data Mining and Machine Learning',2,2,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(29,'Wearable Robotics and Exoskeletons',2,3,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(30,'Cellular Bioengineering',2,4,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(31,'Drug Discovery & Delivery',2,5,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(32,'Epigenetics and Gene Editing Technologies',2,6,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(33,'Advanced Medical Imaging Modalities',2,7,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(34,'Biomedical Engineering',3,1,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(35,'Biomedical Imaging and Signal Processing',3,2,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(36,'Medical Robotics and Automation',3,3,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(37,'Tissue Engineering',3,4,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(38,'Biofabrication and 3D Bioprinting Technologies',3,5,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(39,'Pharmaceutical Engineering',3,6,'2026-10-05 01:01:11','2026-10-05 01:01:11'),(40,'Point-of-Care Diagnostic Technologies',3,7,'2026-10-05 01:01:11','2026-10-05 01:01:11');
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tracks`
--

DROP TABLE IF EXISTS `tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tracks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `badge` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `bullet_points` json DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tracks`
--

LOCK TABLES `tracks` WRITE;
/*!40000 ALTER TABLE `tracks` DISABLE KEYS */;
INSERT INTO `tracks` VALUES (1,'Track I: Emerging infectious diseases through a One health lens','(for medical practitioners)','The convergence of human, animal, and environmental health systems has become central to managing the growing burden of zoonotic and vector-borne disease. Recent scholarship emphasizes that antimicrobial use across human medicine, food-animal production, and aquaculture is a major driver of resistance, underscoring the need for coordinated cross-sectoral action to safeguard both disease control and health-system resilience (Qasim, Khan, & Raza, 2024), since antimicrobials used in food animals and aquaculture for therapy, prophylaxis, and growth promotion contribute significantly to resistance development, making sustainable collaboration across One Health sectors essential. Effective response further depends on integrated surveillance architecture capable of tracking pathogen movement across species and geographic boundaries. Given the complex interactions at the interfaces of environment, livestock, wildlife, and humans, along with the cross-species and regional movement of pathogens, integrated surveillance systems built on strong collaboration among governments, research institutions, and communities are essential for timely, accurate monitoring and response (Bett et al., 2024). This track invites contributions that advance diagnostics, molecular epidemiology, novel antimicrobial strategies, and metagenomic approaches to pathogen emergence within this integrated framework.','[\"Zoonosis\", \"Vector borne diseases\", \"Next generation pandemic preparedness\", \"Environmental Reservoirs and AMR\", \"Molecular Therapeutics and countermeasure innovations\", \"Metagenomics in the wild\", \"Novel antimicrobials\"]',1,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(2,'Track II: Strengthening Health Systems from Theory to Practice: Embedding Social Infrastructure and Public Governance in One Health Capacities',NULL,'Translating One Health principles into durable public health outcomes requires governance architectures capable of sustaining multisectoral coordination beyond crisis-driven response. A recent systematic review of governance mechanisms found that coordinating efforts, fostering partnerships, and establishing effective policy frameworks are essential functions of governance structures in One Health initiatives, while identifying funding limitations, jurisdictional conflict, and insufficient cross-disciplinary communication as persistent obstacles to implementation (2024). Complementary analysis of governance case studies across diverse contexts similarly found that strong political will and crisis-driven momentum tend to facilitate progress, whereas siloed systems, sectoral dominance, limited accountability, and inadequate institutionalisation act as recurring barriers — a finding with particular relevance to antimicrobial resistance, where governance must be sustained outside acute outbreak periods (2025). This track welcomes research on institutional design, workforce capacity, community-led resilience, and the social determinants that shape health-system performance.','[\"Institutional Governance & Multi-Sectoral Policy\", \"Public health policy and One Health governance\", \"Social Infrastructure & Community Resilience\", \"Workforce Development & Operational Capacity\", \"Addressing Social Determinants of Health\", \"Crisis and outbreak management\", \"Community-led health equity\"]',2,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(3,'Track III: Integrating Environment and Climate change in One Health',NULL,'Climate change and biodiversity loss are increasingly understood not as parallel crises but as a single, interdependent threat to planetary and human health. A 2023 cross-journal call for global action argued that climate change and biodiversity loss constitute one indivisible crisis that must be addressed together to protect health and avert catastrophe, given the severity of the resulting environmental emergency (Zielinski et al., 2023). The pathways connecting environmental disruption to disease are wide-ranging: shifts in temperature, precipitation, and land use alter the emergence and spread of vector- and rodent-borne diseases, while deforestation and habitat loss further compound biodiversity decline and infection risk, with changes in temperature, precipitation, and seasonality influencing the emergence, incidence, and spread of diseases such as dengue, malaria, and cholera, and land-use change and deforestation contributing to both biodiversity loss and the spread of infectious diseases such as malaria and Lyme disease (Universidade de Évora, 2023). This track solicits research bridging climate science, ecology, and public health toward climate-resilient, ecosystem-based health strategies.','[\"Climate Change and Pathogen Dynamics\", \"Biodiversity conservation and Biosecurity\", \"Ecosystem resilience\", \"Climate change and Environmental health\", \"Waste management and circular bioeconomy\", \"Mitigating Pollution\", \"Sustainable production systems\"]',3,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(4,'Track IV: Translating Sustainable Chemistry and Future Technologies to One Health',NULL,'Advances in nanotechnology and green chemistry are reshaping the tools available for environmental remediation and contaminant detection. A recent editorial synthesis of the field noted that nanomaterials such as metal oxides, quantum dots, metal-organic frameworks, and graphene-based composites have markedly improved the sensitivity and specificity of contaminant detection, while rising concern over the environmental and health impacts of nanomaterial production has driven research toward greener, lower-toxicity fabrication methods (2025). This shift is occurring alongside growing attention to a broader class of emerging pollutants, with current research priorities spanning pharmaceuticals, personal care products, endocrine disruptors, microplastics, PFAS, and other persistent, bioactive contaminants that resist conventional treatment, alongside sustainable, low-energy remediation solutions responsive to climate and regulatory pressures (Benthamscience, 2025). This track invites contributions on green materials design, biosensing, remediation technology, and the regulatory pathways needed to translate laboratory innovation into field-deployable One Health solutions.','[\"Green Chemistry & Eco-Safe Material Design\", \"Advanced Technologies for Environmental and Pathogen Remediation\", \"Translational Innovation & Regulatory Harmonization\", \"One Health and chemical challenges\", \"Emerging contaminants and environmental chemistry\", \"Sustainable solutions for environmental challenges\"]',4,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(5,'Track V: Ensuring health intervention through the Indian Knowledge System',NULL,'India\'s traditional medical systems represent a vast, largely undocumented reservoir of ethnopharmacological knowledge that is increasingly recognized as both a scientific and legal frontier. A recent review of India\'s intellectual property framework concluded that appropriate guidelines are still needed to bring the diverse medical knowledge of Indigenous communities under a coherent framework that allows these communities to exercise and benefit from their rights over that knowledge, and proposed a human-rights-based, culturally sensitive approach to documentation as a precursor to formal legal recognition (University of Lapland research repository, 2023). This complements the long-standing scholarly mandate to validate traditional claims through rigorous investigation, as reflected in the disciplinary scope of India\'s own traditional-knowledge literature, which encompasses ethno-biology, ethno-medicine, ethno-pharmacology, ethno-pharmacognosy, and clinical studies of efficacy as means of validating indigenous claims regarding plant-, animal-, and mineral-based traditional health-care systems such as Ayurveda, Siddha, Yoga, and Unani (Indian Journal of Traditional Knowledge, CSIR). This track invites work on ethnomedicine, medicinal plant research, and the ethical translation of traditional knowledge into modern therapeutics.','[\"Traditional Healthcare Systems\", \"Ethnomedicine and Community Health Practices\", \"Medicinal Plants and Natural Product Research\", \"Traditional Food Systems, Nutrition and Functional Foods\", \"Biodiversity Conservation and Indigenous Ecological Knowledge\", \"Validation of Traditional Knowledge through Modern Science\", \"Integrative Medicine and Precision Traditional Therapeutics\", \"One Health Perspectives in Indian Knowledge Systems\", \"Digital Documentation and Preservation of Indigenous Knowledge\", \"Policy, Ethics and Intellectual Property Rights in Traditional Knowledge\", \"AI and Omics Approaches for Traditional Medicine Research\", \"Translational Research and Commercialization of IKS-based Innovations\"]',5,'2026-10-07 05:53:11','2026-10-07 05:53:11'),(6,'Track VI: Regenerative Health: Redefining Industrial One Health Paradigms','(for industry track)','The pharmaceutical and life-sciences sectors face mounting pressure to align industrial practice with environmental and social governance (ESG) imperatives, given the sector\'s disproportionate environmental footprint relative to other major industries. Analysis of the sector notes that regulatory frameworks such as the EU\'s Corporate Sustainability Reporting Directive and the International Sustainability Standards Board\'s climate disclosure requirements are compelling pharmaceutical companies and their suppliers to measure and report greenhouse gas emissions, water use, pollution, and governance practices across the full value chain (Neuland Labs, 2025). In the Indian context specifically, supply-chain sustainability is emerging as both an environmental and operational priority, since India\'s pharmaceutical supply chain is among the most complex in the world, and building a sustainable chain — through decentralized manufacturing, low-emission transport, biodegradable packaging, and optimized logistics — is essential not only for environmental reasons but also to strengthen resilience against disruption and reduce cost (Indian Pharmaceutical Alliance, 2025). This track invites contributions on responsible manufacturing, sustainable veterinary and agricultural biologics, and the integration of One Health metrics into corporate ESG reporting.','[\"Responsible Pharmaceutical Manufacturing\", \"Next-Generation Veterinary Biologics\", \"Green Agrochemicals & Biopesticides\", \"Corporate Stewardship & Supply Chain Resilience\", \"Venture Capital in Planetary Health\", \"Cross-Sectoral Commercial Collaboration\", \"Integrating comprehensive One Health metrics into Environmental, Social, and Governance (ESG) corporate reporting standards\"]',6,'2026-10-07 05:53:11','2026-10-07 05:53:11');
/*!40000 ALTER TABLE `tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Test User','test@example.com','2026-08-19 04:16:37','$2y$12$B08KsLkchubJtw7mfc3giODauMR.jH/jB.yx5MVaa5yN/Eg52Zhhq',0,'HpnA9LM7Qu','2026-08-19 04:16:38','2026-08-19 04:16:38'),(2,'Admin User','admin@biomed.com',NULL,'$2y$12$T6CuOyjB34UJwTUQdm3lJuOrTU.QunENWbOczsPJMl1y50mrE.4mi',1,NULL,'2026-08-19 04:16:38','2026-10-05 01:01:10');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-08 11:41:24
